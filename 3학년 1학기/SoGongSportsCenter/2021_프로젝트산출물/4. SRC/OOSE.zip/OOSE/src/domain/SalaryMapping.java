package domain;

public class SalaryMapping {
	private int mapping_id;
	private int employee_id;
	private String name;
	private String participatingCode;
	private String salaryBudgetCode;
	private String payItemCode;
	private String paymentOrDeduction;
	private int price;
	private int projectParticipatingRate;
	private int payItem_id;
	private String itemDetails;
	
	public String getItemDetails() {
		return itemDetails;
	}
	public void setItemDetails(String itemDetails) {
		this.itemDetails = itemDetails;
	}
	public int getMapping_id() {
		return mapping_id;
	}
	public void setMapping_id(int mapping_id) {
		this.mapping_id = mapping_id;
	}
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getParticipatingCode() {
		return participatingCode;
	}
	public void setParticipatingCode(String participatingCode) {
		this.participatingCode = participatingCode;
	}
	public String getSalaryBudgetCode() {
		return salaryBudgetCode;
	}
	public void setSalaryBudgetCode(String salaryBudgetCode) {
		this.salaryBudgetCode = salaryBudgetCode;
	}
	public String getPayItemCode() {
		return payItemCode;
	}
	public void setPayItemCode(String payItemCode) {
		this.payItemCode = payItemCode;
	}
	public String getPaymentOrDeduction() {
		return paymentOrDeduction;
	}
	public void setPaymentOrDeduction(String paymentOrDeduction) {
		this.paymentOrDeduction = paymentOrDeduction;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getProjectParticipatingRate() {
		return projectParticipatingRate;
	}
	public void setProjectParticipatingRate(int projectParticipatingRate) {
		this.projectParticipatingRate = projectParticipatingRate;
	}
	public int getPayItem_id() {
		return payItem_id;
	}
	public void setPayItem_id(int payItem_id) {
		this.payItem_id = payItem_id;
	}
}
