package domain;

public class AssStatement {
	private int assets_number;
	private String assets_name;
	private String price;	
	private String amount;
	private String due_return; 
	private String partname;
	
	public AssStatement() {
		
	}
	
	public AssStatement(int assets_number, String assets_name, String price, String amount, String due_return, String partname) {
		this.assets_number = assets_number;
		this.assets_name = assets_name;
		this.price = price;
		this.amount = amount;
		this.due_return = due_return;
		this.partname = partname;
	}
	
	public int getAssets_number() {
		return assets_number;
	}
	public void setAssets_number(int assets_number) {
		this.assets_number = assets_number;
	}
	public String getAssets_name() {
		return assets_name;
	}
	public void setAssets_name(String assets_name) {
		this.assets_name = assets_name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getDue_return() {
		return due_return;
	}
	public void setDue_return(String due_return) {
		this.due_return = due_return;
	}
	public String getPartname() {
		return partname;
	}
	public void setPartname(String partname) {
		this.partname = partname;
	}

}
