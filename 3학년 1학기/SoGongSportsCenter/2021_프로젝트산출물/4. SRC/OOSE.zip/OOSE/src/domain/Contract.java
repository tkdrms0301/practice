package domain;


import java.sql.Date;

public class Contract {

  private long contractId;
  private String representative;
  private String contractName;
  private long contractMoney;
  private java.sql.Date contractStartDate;
  private java.sql.Date contractEndDate;
  private String region;
  private String approvalState;
  private String remark;

  public Contract() {
  }

  public Contract(long contractId, String representative, String contractName, long contractMoney, Date contractStartDate, Date contractEndDate, String region, String approvalState, String remark) {
    this.contractId = contractId;
    this.representative = representative;
    this.contractName = contractName;
    this.contractMoney = contractMoney;
    this.contractStartDate = contractStartDate;
    this.contractEndDate = contractEndDate;
    this.region = region;
    this.approvalState = approvalState;
    this.remark = remark;
  }

  public long getContractId() {
    return contractId;
  }

  public void setContractId(long contractId) {
    this.contractId = contractId;
  }


  public String getRepresentative() {
    return representative;
  }

  public void setRepresentative(String representative) {
    this.representative = representative;
  }


  public String getContractName() {
    return contractName;
  }

  public void setContractName(String contractName) {
    this.contractName = contractName;
  }


  public long getContractMoney() {
    return contractMoney;
  }

  public void setContractMoney(long contractMoney) {
    this.contractMoney = contractMoney;
  }


  public java.sql.Date getContractStartDate() {
    return contractStartDate;
  }

  public void setContractStartDate(java.sql.Date contractStartDate) {
    this.contractStartDate = contractStartDate;
  }


  public java.sql.Date getContractEndDate() {
    return contractEndDate;
  }

  public void setContractEndDate(java.sql.Date contractEndDate) {
    this.contractEndDate = contractEndDate;
  }


  public String getRegion() {
    return region;
  }

  public void setRegion(String region) {
    this.region = region;
  }


  public String getApprovalState() {
    return approvalState;
  }

  public void setApprovalState(String approvalState) {
    this.approvalState = approvalState;
  }


  public String getRemark() {
    return remark;
  }

  public void setRemark(String remark) {
    this.remark = remark;
  }

}
