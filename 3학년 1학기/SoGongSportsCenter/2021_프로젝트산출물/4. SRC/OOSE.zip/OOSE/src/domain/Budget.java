package domain;

public class Budget {
	private int id;
	private int businessCode;
	private String employee;
	private String approvalType;
	private String detail;
	private int organizationBudget;
	private String executionDetails;
	private String approval;
	private String reason;
	public Budget() {}
	public Budget(int id, int businessCode, String employee, String approvalType, String detail, int organizationBudget, String executionDetails, String approval, String reason) {		
		this.id = id;
		this.businessCode = businessCode;
		this.employee = employee;
		this.approvalType = approvalType;
		this.detail = detail;
		this.organizationBudget = organizationBudget;
		this.executionDetails = executionDetails;
		this.approval = approval;
		this.reason = reason;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBusinessCode() {
		return businessCode;
	}
	public void setBusinessCode(int businessCode) {
		this.businessCode = businessCode;
	}
	public String getEmployee() {
		return employee;
	}
	public void setEmployee(String employee) {
		this.employee = employee;
	}
	public String getApprovalType() {
		return approvalType;
	}
	public void setApprovalType(String approvalType) {
		this.approvalType = approvalType;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public int getOrganizationBudget() {
		return organizationBudget;
	}
	public void setOrganizationBudget(int organizationBudget) {
		this.organizationBudget = organizationBudget;
	}
	public String getExecutionDetails() {
		return executionDetails;
	}
	public void setExecutionDetails(String executionDetails) {
		this.executionDetails = executionDetails;
	}
	public String getApproval() {
		return approval;
	}
	public void setApproval(String approval) {
		this.approval = approval;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}

}
