package domain;

public class PayItem {
	private int payItem_id;
	private String paymentOrDeduction;
	private String salaryBudgetCode;
	private String payItemCode;
	private int price;
	private String itemDetails;
	public int getPayItem_id() {
		return payItem_id;
	}
	public void setPayItem_id(int payItem_id) {
		this.payItem_id = payItem_id;
	}
	public String getPaymentOrDeduction() {
		return paymentOrDeduction;
	}
	public void setPaymentOrDeduction(String paymentOrDeduction) {
		this.paymentOrDeduction = paymentOrDeduction;
	}
	public String getSalaryBudgetCode() {
		return salaryBudgetCode;
	}
	public void setSalaryBudgetCode(String salaryBudgetCode) {
		this.salaryBudgetCode = salaryBudgetCode;
	}
	public String getPayItemCode() {
		return payItemCode;
	}
	public void setPayItemCode(String payItemCode) {
		this.payItemCode = payItemCode;
	}
	public int getPrice() {
		return price;
	}
	public  void setPrice(int price) {
		this.price = price;
	}
	public String getItemDetails() {
		return itemDetails;
	}
	public void setItemDetails(String itemDetails) {
		this.itemDetails = itemDetails;
	}
	public PayItem() {}
	public PayItem(int payItem_id, String paymentOrDeduction, String salaryBudgetCode, String payItemCode, int price,
			String itemDetails) {
		super();
		this.payItem_id = payItem_id;
		this.paymentOrDeduction = paymentOrDeduction;
		this.salaryBudgetCode = salaryBudgetCode;
		this.payItemCode = payItemCode;
		this.price = price;
		this.itemDetails = itemDetails;
	}
}
