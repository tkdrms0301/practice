package domain;

import java.util.Date;
import java.sql.Time;

public class WorkingHours {
	private Date childcare_apply_set_starting_date;
	private Date childcare_apply_set_quitting_date;
	private Time overtime_apply_set_starting_time;
	private Time overtime_apply_set_quitting_time;

	public WorkingHours() {
		
	}
	
	public WorkingHours(Date childcare_apply_set_starting_date, Date childcare_apply_set_quitting_date,
			Time overtime_apply_set_starting_time, Time overtime_apply_set_quitting_time) {
		this.childcare_apply_set_starting_date = childcare_apply_set_starting_date;
		this.childcare_apply_set_quitting_date = childcare_apply_set_quitting_date;
		this.overtime_apply_set_starting_time = overtime_apply_set_starting_time;
		this.overtime_apply_set_quitting_time = overtime_apply_set_quitting_time;
	}

	public Date getChildcare_apply_set_starting_date() {
		return childcare_apply_set_starting_date;
	}

	public void setChildcare_apply_set_starting_date(Date childcare_apply_set_starting_date) {
		this.childcare_apply_set_starting_date = childcare_apply_set_starting_date;
	}

	public Date getChildcare_apply_set_quitting_date() {
		return childcare_apply_set_quitting_date;
	}

	public void setChildcare_apply_set_quitting_date(Date childcare_apply_set_quitting_date) {
		this.childcare_apply_set_quitting_date = childcare_apply_set_quitting_date;
	}

	public Time getOvertime_apply_set_starting_time() {
		return overtime_apply_set_starting_time;
	}

	public void setOvertime_apply_set_starting_time(Time overtime_apply_set_starting_time) {
		this.overtime_apply_set_starting_time = overtime_apply_set_starting_time;
	}

	public Time getOvertime_apply_set_quitting_time() {
		return overtime_apply_set_quitting_time;
	}

	public void setOvertime_apply_set_quitting_time(Time overtime_apply_set_quitting_time) {
		this.overtime_apply_set_quitting_time = overtime_apply_set_quitting_time;
	}
}
