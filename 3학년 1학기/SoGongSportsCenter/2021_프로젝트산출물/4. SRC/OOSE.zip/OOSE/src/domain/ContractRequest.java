package domain;


import java.sql.Date;

public class ContractRequest {

  private long contractRequestId;
  private String contractName;
  private java.sql.Date requestDate;
  private String contractType;
  private long reannouncement;
  private long newBid;

  public ContractRequest(){

  }

  public ContractRequest(long contractRequestId, String contractName, Date requestDate, String contractType, long reannouncement, long newBid) {
    this.contractRequestId = contractRequestId;
    this.contractName = contractName;
    this.requestDate = requestDate;
    this.contractType = contractType;
    this.reannouncement = reannouncement;
    this.newBid = newBid;
  }

  public long getContractRequestId() {
    return contractRequestId;
  }

  public void setContractRequestId(long contractRequestId) {
    this.contractRequestId = contractRequestId;
  }

  public String getContractName() {
    return contractName;
  }

  public void setContractName(String contractName) {
    this.contractName = contractName;
  }


  public java.sql.Date getRequestDate() {
    return requestDate;
  }

  public void setRequestDate(java.sql.Date requestDate) {
    this.requestDate = requestDate;
  }


  public String getContractType() {
    return contractType;
  }

  public void setContractType(String contractType) {
    this.contractType = contractType;
  }


  public long getReannouncement() {
    return reannouncement;
  }

  public void setReannouncement(long reannouncement) {
    this.reannouncement = reannouncement;
  }


  public long getNewBid() {
    return newBid;
  }

  public void setNewBid(long newBid) {
    this.newBid = newBid;
  }

}
