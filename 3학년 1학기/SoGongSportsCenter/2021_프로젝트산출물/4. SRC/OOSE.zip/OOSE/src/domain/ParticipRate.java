package domain;

public class ParticipRate {
	private int participRate_id;
	private int employee_id;
	private int rate; // ������ *100���� ȯ���Ͽ� �����Ѵ�.
	private int isRemoved;
	private Employee employee;

	public ParticipRate() {
	};

	public ParticipRate(int participRate_id, int employee_id, int rate, int isRemoved) {
		super();
		this.participRate_id = participRate_id;
		this.employee_id = employee_id;
		this.rate = rate;
		this.isRemoved = isRemoved;
	}

	public int getParticipRate_id() {
		return participRate_id;
	}

	public void setParticipRate_id(int participRate_id) {
		this.participRate_id = participRate_id;
	}

	public int getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getIsRemoved() {
		return isRemoved;
	}

	public void setIsRemoved(int isRemoved) {
		this.isRemoved = isRemoved;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
}
