package domain;

public class Board {
	private Long employee_id;
	private String name;
	private String phone_number;
	private String position;
	private String employee_classification;
	private String affiliation;
	private int age;
	private String gender;
	private String working_status;
	private String assignment;
	private String education;
	private String major;
	private String disabled;
	private String rewarding_patriotism;
	private String salary_peak;
	private String recruitment;
	private int entered_date;
	
	public Board() {}
	public Board(Long employee_id, String name, String phone_number, String position, String employee_classification, String affiliation, int age, 
			String gender, String working_status, String assignment, String education, String major, String disabled, String rewarding_patriotism,
			String salary_peak, String recruitment, int entered_date) {
		this.employee_id = employee_id;
		this.name = name;
		this.phone_number = phone_number;
		this.position = position;
		this.employee_classification = employee_classification;
		this.affiliation = affiliation;
		this.age = age;
		this.gender = gender;
		this.working_status = working_status;
		this.assignment = assignment;
		this.education = education;
		this.major = major;
		this.disabled = disabled;
		this.rewarding_patriotism = rewarding_patriotism;
		this.salary_peak = salary_peak;
		this.recruitment = recruitment;
		this.entered_date = entered_date;
		
	}
	
	public Long getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(Long employee_id) {
		this.employee_id = employee_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getEmployee_classification() {
		return employee_classification;
	}
	public void setEmployee_classification(String employee_classification) {
		this.employee_classification = employee_classification;
	}
	public String getAffiliation() {
		return affiliation;
	}
	public void setAffiliation(String affiliation) {
		this.affiliation = affiliation;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getWorking_status() {
		return working_status;
	}
	public void setWorking_status(String working_status) {
		this.working_status = working_status;
	}
	public String getAssignment() {
		return assignment;
	}
	public void setAssignment(String assignment) {
		this.assignment = assignment;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getDisabled() {
		return disabled;
	}
	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}
	public String getRewarding_patriotism() {
		return rewarding_patriotism;
	}
	public void setRewarding_patriotism(String rewarding_patriotism) {
		this.rewarding_patriotism = rewarding_patriotism;
	}
	public String getSalary_peak() {
		return salary_peak;
	}
	public void setSalary_peak(String salary_peak) {
		this.salary_peak = salary_peak;
	}
	public String getRecruitment() {
		return recruitment;
	}
	public void setRecruitment(String recruitment) {
		this.recruitment = recruitment;
	}
	public int getEntered_date() {
		return entered_date;
	}
	public void setEntered_date(int entered_date) {
		this.entered_date = entered_date;
	}
}
