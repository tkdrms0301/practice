package domain;

import java.time.LocalDateTime;

public class LaborCost {
	private int laborcost_id;
	private int employee_id;
	private String payment;
	private int isRemoved;
	private Employee employee;
	private LocalDateTime date;

	public LaborCost() {
	}

	public LaborCost(int laborcost_id, int employee_id, String payment, LocalDateTime date, int isRemoved) {
		super();
		this.laborcost_id = laborcost_id;
		this.employee_id = employee_id;
		this.payment = payment;
		this.date = date;
		this.isRemoved = isRemoved;
	}

	public int getLaborcost_id() {
		return laborcost_id;
	}

	public void setLaborcost_id(int laborcost_id) {
		this.laborcost_id = laborcost_id;
	}

	public int getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public int getIsRemoved() {
		return isRemoved;
	}

	public void setIsRemoved(int isRemoved) {
		this.isRemoved = isRemoved;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
}
