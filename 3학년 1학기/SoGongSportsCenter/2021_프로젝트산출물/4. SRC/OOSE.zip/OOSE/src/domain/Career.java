package domain;

import java.util.Date;

public class Career {
	private int career_id;
	private int employee_id;
	private String name;
	private String education;
	private String performed;
	private String evaluation;
	private String punishment;
	private java.sql.Date longevity;
	private String training;
	private String certificate;
	private String prize;
	private String task;
	private String jop_experience;
	
	public Career() {}
	
	public Career(int career_id, int employee_id, String education, String performed, String evaluation,
			String punishment, java.sql.Date longevity, String training, String certificate, String prize, String task,
			String jop_experience) {
		super();
		this.career_id = career_id;
		this.employee_id = employee_id;
		this.education = education;
		this.performed = performed;
		this.evaluation = evaluation;
		this.punishment = punishment;
		this.longevity = longevity;
		this.training = training;
		this.certificate = certificate;
		this.prize = prize;
		this.task = task;
		this.jop_experience = jop_experience;
	}
	
	public int getCareer_id() {
		return career_id;
	}
	public void setCareer_id(int career_id) {
		this.career_id = career_id;
	}
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getPerformed() {
		return performed;
	}
	public void setPerformed(String performed) {
		this.performed = performed;
	}
	public String getEvaluation() {
		return evaluation;
	}
	public void setEvaluation(String evaluation) {
		this.evaluation = evaluation;
	}
	public String getPunishment() {
		return punishment;
	}
	public void setPunishment(String punishment) {
		this.punishment = punishment;
	}
	public java.sql.Date getLongevity() {
		return longevity;
	}
	public void setLongevity(java.sql.Date longevity) {
		this.longevity = longevity;
	}
	public String getTraining() {
		return training;
	}
	public void setTraining(String training) {
		this.training = training;
	}
	public String getCertificate() {
		return certificate;
	}
	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}
	public String getPrize() {
		return prize;
	}
	public void setPrize(String prize) {
		this.prize = prize;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJop_experience() {
		return jop_experience;
	}
	public void setJop_experience(String jop_experience) {
		this.jop_experience = jop_experience;
	}
}
