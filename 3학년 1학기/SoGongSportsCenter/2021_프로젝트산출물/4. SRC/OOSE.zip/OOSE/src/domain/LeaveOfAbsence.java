package domain;

import java.util.Date;

public class LeaveOfAbsence {
	private int leave_of_absence_id;
	private String name;
	private String position;
	private String department;
	private int leaveState;
	private Date startPeriodDay;
	private Date endPeriodDay;
	private String leaveReason;
	private String leaveSignificant;

	public LeaveOfAbsence() {

	}

	public LeaveOfAbsence(int leave_of_absence_id, String name, String position, String department, int leaveState, Date startPeriodDay, Date endPeriodDay, String leaveReason, String leaveSignificant) {
		this.leave_of_absence_id = leave_of_absence_id;
		this.name = name;
		this.position = position;
		this.department = department;
		this.leaveState = leaveState;
		this.startPeriodDay = startPeriodDay;
		this.endPeriodDay = endPeriodDay;
		this.leaveReason = leaveReason;
		this.leaveSignificant = leaveSignificant;
	}

	public int getLeave_of_absence_id() {
		return leave_of_absence_id;
	}

	public void setLeave_of_absence_id(int leave_of_absence_id) {
		this.leave_of_absence_id = leave_of_absence_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
	
	public int getLeaveState() {
		return leaveState;
	}

	public void setLeaveState(int leaveState) {
		this.leaveState = leaveState;
	}

	public Date getStartPeriodDay() {
		return startPeriodDay;
	}

	public void setStartPeriodDay(Date startPeriodDay) {
		this.startPeriodDay = startPeriodDay;
	}

	public Date getEndPeriodDay() {
		return endPeriodDay;
	}

	public void setEndPeriodDay(Date endPeriodDay) {
		this.endPeriodDay = endPeriodDay;
	}

	public String getLeaveReason() {
		return leaveReason;
	}

	public void setLeaveReason(String leaveReason) {
		this.leaveReason = leaveReason;
	}

	public String getLeaveSignificant() {
		return leaveSignificant;
	}

	public void setLeaveSignificant(String leaveSignificant) {
		this.leaveSignificant = leaveSignificant;
	}

}