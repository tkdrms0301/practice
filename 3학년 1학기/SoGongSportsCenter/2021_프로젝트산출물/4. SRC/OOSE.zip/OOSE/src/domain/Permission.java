package domain;

public class Permission {
	private int business_number;
	private String business_name;

	public Permission() {
		
	}
	
	public Permission(int business_number, String business_name) {
		this.business_number = business_number;
		this.business_name = business_name;
	}

	public int getBusiness_number() {
		return business_number;
	}

	public void setBusiness_number(int business_number) {
		this.business_number = business_number;
	}

	public String getBusiness_name() {
		return business_name;
	}

	public void setBusiness_name(String business_name) {
		this.business_name = business_name;
	}

	

}
