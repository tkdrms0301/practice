package domain;

import java.sql.Timestamp;
import java.util.Date;

public class Asset {
	private int ass_number;
	private String ass_name;
	private String loss;	
	private String sell;
	private String ass_present;
	private String turn_in;
	public Asset() {
		
	}

	public Asset(int ass_number, String ass_name, String loss, String sell, String ass_present, String turn_in) {
		this.ass_number = ass_number;
		this.ass_name = ass_name;
		this.loss = loss;
		this.sell = sell;
		this.ass_present = ass_present;
		this.turn_in = turn_in;
	}
	
	public int getAss_number() {
		return ass_number;
	}

	public void setAss_number(int ass_number) {
		this.ass_number = ass_number;
	}

	public String getAss_name() {
		return ass_name;
	}

	public void setAss_name(String ass_name) {
		this.ass_name = ass_name;
	}

	public String getLoss() {
		return loss;
	}

	public void setLoss(String loss) {
		this.loss = loss;
	}

	public String getSell() {
		return sell;
	}

	public void setSell(String sell) {
		this.sell = sell;
	}

	public String getAss_present() {
		return ass_present;
	}

	public void setAss_present(String ass_present) {
		this.ass_present = ass_present;
	}
	
	public String getTurn_in() {
		return turn_in;
	}

	public void setTurn_in(String turn_in) {
		this.turn_in = turn_in;
	}

	public void setStartPeriodDay(Date startDay) {
		// TODO Auto-generated method stub
		
	}

	public String getAstSignificant() {
		// TODO Auto-generated method stub
		return null;
	}




}
