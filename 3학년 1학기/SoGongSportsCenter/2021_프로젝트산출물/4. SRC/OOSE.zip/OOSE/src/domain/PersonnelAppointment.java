package domain;

public class PersonnelAppointment {
	private int personnel_appointment_id;
	private int employee_id;
	private String division;
	private String position;
	private String name;
	private String department;
	private String personnel_appointment;
	private String remarks;
	
	public PersonnelAppointment() {}
	
	public int getPersonnel_appointment_id() {
		return personnel_appointment_id;
	}
	public void setPersonnel_appointment_id(int personnel_appointment_id) {
		this.personnel_appointment_id = personnel_appointment_id;
	}
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPersonnel_appointment() {
		return personnel_appointment;
	}
	public void setPersonnel_appointment(String personnel_appointment) {
		this.personnel_appointment = personnel_appointment;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
