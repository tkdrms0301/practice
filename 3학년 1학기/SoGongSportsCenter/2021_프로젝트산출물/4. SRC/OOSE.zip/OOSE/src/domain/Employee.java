package domain;

import java.time.LocalDateTime;

public class Employee {
	private int employee_id;
	private String name;
	private int phone_number;
	private int position;
	private String employee_classification;
	private String affiliation;
	private int age;
	private int gender;
	private String working_status;
	private String major;
	private int disabled;
	private int rewarding_patriotism;
	private int salary_peak;
	private int recruitment;
	private LocalDateTime entered_date;
	private String Employeecol;

	public Employee() {
	};

	public Employee(int employee_id, String name, int phone_number, int position, String employee_classification,
			String affiliation, int age, int gender, String working_status, String major, int disabled,
			int rewarding_patriotism, int salary_peak, int recruitment, LocalDateTime entered_date,
			String employeecol) {
		super();
		this.employee_id = employee_id;
		this.name = name;
		this.phone_number = phone_number;
		this.position = position;
		this.employee_classification = employee_classification;
		this.affiliation = affiliation;
		this.age = age;
		this.gender = gender;
		this.working_status = working_status;
		this.major = major;
		this.disabled = disabled;
		this.rewarding_patriotism = rewarding_patriotism;
		this.salary_peak = salary_peak;
		this.recruitment = recruitment;
		this.entered_date = entered_date;
		Employeecol = employeecol;
	}

	public int getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(int phone_number) {
		this.phone_number = phone_number;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public String getEmployee_classification() {
		return employee_classification;
	}

	public void setEmployee_classification(String employee_classification) {
		this.employee_classification = employee_classification;
	}

	public String getAffiliation() {
		return affiliation;
	}

	public void setAffiliation(String affiliation) {
		this.affiliation = affiliation;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getGender() {
		return gender;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public String getWorking_status() {
		return working_status;
	}

	public void setWorking_status(String working_status) {
		this.working_status = working_status;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public int getDisabled() {
		return disabled;
	}

	public void setDisabled(int disabled) {
		this.disabled = disabled;
	}

	public int getRewarding_patriotism() {
		return rewarding_patriotism;
	}

	public void setRewarding_patriotism(int rewarding_patriotism) {
		this.rewarding_patriotism = rewarding_patriotism;
	}

	public int getSalary_peak() {
		return salary_peak;
	}

	public void setSalary_peak(int salary_peak) {
		this.salary_peak = salary_peak;
	}

	public int getRecruitment() {
		return recruitment;
	}

	public void setRecruitment(int recruitment) {
		this.recruitment = recruitment;
	}

	public LocalDateTime getEntered_date() {
		return entered_date;
	}

	public void setEntered_date(LocalDateTime entered_date) {
		this.entered_date = entered_date;
	}

	public String getEmployeecol() {
		return Employeecol;
	}

	public void setEmployeecol(String employeecol) {
		Employeecol = employeecol;
	}
}
