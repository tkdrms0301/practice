package persistence;

import domain.Contract;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;

public class ContractRepository {
    private static ContractRepository instance;
    private static DataSource ds;
    private ContractRepository() {

    }
    public static ContractRepository getInstance() {
        if(instance==null) {
            try {
                Context context = new InitialContext();
                ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
                return instance = new ContractRepository();
            } catch (NamingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return instance;
    }

    public ArrayList<Contract> findAll() {
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;

        String sql = "SELECT * FROM CONTRACT";
        ArrayList<Contract> contracts = new ArrayList<Contract>();

        try {
            conn = ds.getConnection();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()) {
                int id = rs.getInt("contract_id");
                String representative = rs.getString("representative");
                String contractName = rs.getString("contract_name");
                Long contractMoney = rs.getLong("contract_money");
                Date contractStartDate = rs.getDate("contract_start_date");
                Date contractEndDate = rs.getDate("contract_end_date");
                String region = rs.getString("region");
                String approvalState = rs.getString("approval_state");
                String remark = rs.getString("remark");

                Contract contract = new Contract(id,representative,contractName,contractMoney
                        ,contractStartDate,contractEndDate,region,approvalState, remark);

                contracts.add(contract);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            try {
                rs.close();
                st.close();
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return contracts;
    }

    public void save(Contract contract) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        String sql = "INSERT INTO CONTRACT(representative, contract_name, contract_money, " +
                "contract_start_date, contract_end_date, region, remark) values(?,?,?,?,?,?,?)";
        try {
            conn = ds.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, contract.getRepresentative());
            pstmt.setString(2, contract.getContractName());
            pstmt.setLong(3, contract.getContractMoney());
            pstmt.setDate(4, contract.getContractStartDate());
            pstmt.setDate(5, contract.getContractEndDate());
            pstmt.setString(6, contract.getRegion());
            pstmt.setString(7, contract.getRemark());

            pstmt.executeUpdate();
        }catch(SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                pstmt.close();
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    public void update(Contract contract) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        String sql = "UPDATE CONTRACT SET representative = ?, contract_name = ?, contract_money = ?, contract_start_date = ?, contract_end_date = ?, region = ?, approval_state = ?, remark = ? WHERE contract_id = ?";
        try {
            conn = ds.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, contract.getRepresentative());
            pstmt.setString(2, contract.getContractName());
            pstmt.setLong(3, contract.getContractMoney());
            pstmt.setDate(4, contract.getContractStartDate());
            pstmt.setDate(5, contract.getContractEndDate());
            pstmt.setString(6, contract.getRegion());
            pstmt.setString(7, contract.getApprovalState());
            pstmt.setString(8, contract.getRemark());
            pstmt.setLong(9, contract.getContractId());

            pstmt.executeUpdate();
        }catch(SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                pstmt.close();
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    public Contract findById(String contractId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Contract contract = null;

        String sql = "SELECT * FROM CONTRACT WHERE (contract_id=?)";

        try {
            conn = ds.getConnection();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setLong(1, Long.parseLong(contractId));
            rs = pstmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("contract_id");
                String representative = rs.getString("representative");
                String contractName = rs.getString("contract_name");
                Long contractMoney = rs.getLong("contract_money");
                Date contractStartDate = rs.getDate("contract_start_date");
                Date contractEndDate = rs.getDate("contract_end_date");
                String region = rs.getString("region");
                String approvalState = rs.getString("approval_state");
                String remark = rs.getString("remark");


                contract = new Contract(id,representative,contractName,contractMoney
                        ,contractStartDate,contractEndDate,region,approvalState, remark);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        return contract;
    }
}
