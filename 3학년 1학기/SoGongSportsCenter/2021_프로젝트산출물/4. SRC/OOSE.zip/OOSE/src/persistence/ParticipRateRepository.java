package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.ParticipRate;
import domain.Employee;

public class ParticipRateRepository {
	private static ParticipRateRepository instance;
	private static DataSource ds;

	public static ParticipRateRepository getInstacne() {
		if (instance == null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new ParticipRateRepository();
			} catch (NamingException e) {
				e.printStackTrace();
			}
		}
		return instance;
	}

	public void insert(ParticipRate rate) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO participrate(employee_id,rate) VALUES (?,?)";
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, rate.getEmployee_id());
			pstmt.setInt(2, rate.getRate());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void delete(ParticipRate rate) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "DELETE FROM participrate WHERE participRate_id=?";
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, rate.getParticipRate_id());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public ArrayList<ParticipRate> findAll() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM employee LEFT OUTER JOIN participrate ON employee.employee_id=participrate.employee_id";
		ArrayList<ParticipRate> datas = new ArrayList<ParticipRate>();
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ParticipRate rate = new ParticipRate();
				Employee employee = new Employee();
				int participRate_id = rs.getInt("participrate.participrate_id");
				int employee_id = rs.getInt("employee_id");
				String employee_name = rs.getString("employee.name");
				int employee_position = rs.getInt("employee.position");
				int participrate = rs.getInt("participrate.rate");
				employee.setName(employee_name);
				employee.setPosition(employee_position);
				rate.setEmployee_id(employee_id);
				rate.setRate(participrate);
				rate.setEmployee(employee);
				rate.setParticipRate_id(participRate_id);
				datas.add(rate);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return datas;
	}

	public void update(ParticipRate rate) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE participrate SET rate=? WHERE participRate_id=?";
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, rate.getRate());
			pstmt.setInt(2, rate.getParticipRate_id());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
