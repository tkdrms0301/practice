package persistence;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.Asset;

import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.sql.Connection;

public class AssetRepository {
	ArrayList<Asset> list;
	Asset dto;
	private static AssetRepository instance;
	private static DataSource ds;

	public AssetRepository() {

	}

	public static AssetRepository getInstacne() {
		if (instance == null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new AssetRepository();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instance;
	}

	
	
	
	public static Asset read(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM Asset WHERE id=?";
		Asset Asset = new Asset();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Asset.setAss_number(rs.getInt(1));
				Asset.setAss_name(rs.getString(2));
				Asset.setLoss(rs.getString(3));
				Asset.setSell(rs.getString(4));
				Asset.setAss_present(rs.getString(5));
				Asset.setTurn_in(rs.getString(6));
				
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
				else if (rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return Asset;
	}

	public void write(Asset data) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO Asset(ass_number, ass_name,loss, sell, ass_present, turn_in) VALUES (?,?,?,?,?)";

		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, data.getAss_number());
			pstmt.setString(2, data.getAss_name());
			pstmt.setString(3, data.getLoss());
			pstmt.setString(4, data.getSell());
			pstmt.setString(5, data.getAss_present());
			pstmt.setString(6, "0");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void update(Asset data) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE Asset SET ass_name=?,loss=?,sell=? where id=?;";

		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, data.getAss_number());
			pstmt.setString(2, data.getAss_name());
			pstmt.setString(3, data.getLoss());
			pstmt.setString(4, data.getSell());
			pstmt.setString(5, data.getTurn_in());
			pstmt.executeUpdate();
	

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public Asset findById(int ass_number) {
		return null;
	}
	
	


	public ArrayList<Asset> findAll() {
		System.out.print("---------------");
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM asset";
		ArrayList<Asset> at = new ArrayList<Asset>();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int ass_number = rs.getInt("ass_number");
				String ass_name = rs.getString("ass_name");
				String loss = rs.getString("loss");
				String sell = rs.getString("sell");
				String ass_present = rs.getString("ass_present");
				String turn_in = rs.getString("turn_in");
				Asset ass = new Asset(ass_number, ass_name, loss, sell, ass_present, turn_in);
				at.add(ass);
			}
			
	
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return at;
	}
}
