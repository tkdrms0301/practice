package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.Career;

public class CareerRepo {
	private static CareerRepo instance;
	private static DataSource ds;
	public CareerRepo() {
		
	}
	public static CareerRepo getInstacne() {
		if(instance==null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new CareerRepo();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instance;		
	}
	
	public void enroll(Career career){
		Connection conn = null;
		PreparedStatement pstmt = null; 
		
		String sql = "INSERT INTO career (Employee_employee_id, education, performed,punishiment, longevity, training, certificate,prize, task, jop_experience) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);			
			pstmt.setInt(1, career.getEmployee_id());
			pstmt.setString(2, career.getEducation());
			pstmt.setString(3, career.getPerformed());
			pstmt.setString(4, career.getPunishment());
			pstmt.setDate(5, career.getLongevity());
			pstmt.setString(6, career.getTraining());
			pstmt.setString(7, career.getCertificate());
			pstmt.setString(8, career.getPrize());
			pstmt.setString(9, career.getTask());
			pstmt.setString(10, career.getJop_experience());
			
			int n = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
	}
	public ArrayList<Career> findAll()
	{
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = "SELECT  career.*, employee.name FROM career, employee where career.Employee_employee_id = employee.employee_id ORDER BY career.Employee_employee_id DESC;";
		ArrayList<Career> careers = new ArrayList<Career>();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				Career career = new Career();
				career.setCareer_id(rs.getInt("career_id"));
				career.setEmployee_id(rs.getInt("Employee_employee_id"));
				career.setEducation(rs.getString("education"));
				career.setPerformed(rs.getString("performed"));
				career.setPunishment(rs.getString("punishiment"));
				career.setLongevity(rs.getDate("longevity"));
				career.setTraining(rs.getString("training"));
				career.setCertificate(rs.getString("certificate"));
				career.setPrize(rs.getString("prize"));
				career.setTask(rs.getString("task"));
				career.setJop_experience(rs.getString("jop_experience"));
				career.setName(rs.getString("name"));
				career.setEvaluation(rs.getString("evaluation"));
				careers.add(career);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}		
		return careers;	
	}
	public Career findById(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null; 
		ResultSet rs = null;
		String sql = "SELECT * FROM career Where Employee_employee_id=?";
		Career career = new Career();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				career.setCareer_id(rs.getInt("career_id"));
				career.setEmployee_id(rs.getInt("Employee_employee_id"));
				career.setEducation(rs.getString("education"));
				career.setPerformed(rs.getString("performed"));
				career.setPunishment(rs.getString("punishiment"));
				career.setLongevity(rs.getDate("longevity"));
				career.setTraining(rs.getString("training"));
				career.setCertificate(rs.getString("certificate"));
				career.setPrize(rs.getString("prize"));
				career.setTask(rs.getString("task"));
				career.setEvaluation(rs.getString("evaluation"));
				career.setJop_experience(rs.getString("jop_experience"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}		
		return career;
	}
	public void update(Career career) {
		Connection conn = null;
		PreparedStatement pstmt = null; 
		
		String sql = "UPDATE career SET Employee_employee_id = ?, education = ?, performed = ?, punishiment = ?, longevity = ?, training = ?, certificate = ?, prize = ?, task = ?, jop_experience = ?, evaluation = ? WHERE career_id = ?;";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);			
			pstmt.setInt(1, career.getEmployee_id());
			pstmt.setString(2, career.getEducation());
			pstmt.setString(3, career.getPerformed());
			pstmt.setString(4, career.getPunishment());
			pstmt.setDate(5, career.getLongevity());
			pstmt.setString(6, career.getTraining());
			pstmt.setString(7, career.getCertificate());
			pstmt.setString(8, career.getPrize());
			pstmt.setString(9, career.getTask());
			pstmt.setString(10, career.getJop_experience());
			pstmt.setString(11, career.getEvaluation());
			pstmt.setInt(12, career.getCareer_id());
			System.out.println(career.getCareer_id());
			pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}			
		}
	}
}