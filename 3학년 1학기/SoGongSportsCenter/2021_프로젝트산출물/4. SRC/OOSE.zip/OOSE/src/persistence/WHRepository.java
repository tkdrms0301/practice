package persistence;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.LeaveOfAbsence;
import domain.WorkingHours;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.sql.Connection;

public class WHRepository {
	ArrayList<WorkingHours> list;
	WorkingHours dto;
	private static WHRepository instance;
	private static DataSource ds;

	public WHRepository() {

	}

	public static WHRepository getInstacne() {
		if (instance == null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new WHRepository();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instance;
	}

	public void daySet(WorkingHours data) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql2 = "UPDATE working_hours SET childcare_apply_set_starting_date=?, childcare_apply_set_quitting_date=?";

		try {
			conn = ds.getConnection();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql2);
			long timeInMilliSeconds = data.getChildcare_apply_set_starting_date().getTime();
			java.sql.Date st = new java.sql.Date(timeInMilliSeconds);
			long timeInMilliSeconds2 = data.getChildcare_apply_set_quitting_date().getTime();
			java.sql.Date et = new java.sql.Date(timeInMilliSeconds2);
			pstmt.setDate(1, st);
			pstmt.setDate(2, et);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void timeSet(WorkingHours data) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE working_hours SET overtime_apply_set_starting_time=?, overtime_apply_set_quitting_time=?";

		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			long timeInMilliSeconds = data.getOvertime_apply_set_starting_time().getTime();
			java.sql.Time st = new java.sql.Time(timeInMilliSeconds);
			long timeInMilliSeconds2 = data.getOvertime_apply_set_quitting_time().getTime();
			java.sql.Time et = new java.sql.Time(timeInMilliSeconds2);
			pstmt.setTime(1, st);
			pstmt.setTime(2, et);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
