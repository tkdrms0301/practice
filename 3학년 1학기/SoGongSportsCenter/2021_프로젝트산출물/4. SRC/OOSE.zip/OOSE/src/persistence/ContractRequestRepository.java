package persistence;

import domain.Contract;
import domain.ContractRequest;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;

public class ContractRequestRepository {
    private static ContractRequestRepository instance;
    private static DataSource ds;
    private ContractRequestRepository() {

    }
    public static ContractRequestRepository getInstance() {
        if(instance==null) {
            try {
                Context context = new InitialContext();
                ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
                return instance = new ContractRequestRepository();
            } catch (NamingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return instance;
    }

    public ArrayList<ContractRequest> findAll() {
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;

        String sql = "SELECT * FROM CONTRACT_REQUEST";
        ArrayList<ContractRequest> contractRequests = new ArrayList<ContractRequest>();

        try {
            conn = ds.getConnection();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            st = conn.createStatement();
            rs = st.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("contract_request_id");
                String contractName = rs.getString("contract_name");
                Date requestDate = rs.getDate("request_date");
                String contractType = rs.getString("contract_type");
                Long reannouncement = rs.getLong("reannouncement");
                Long newBid = rs.getLong("new_bid");

                ContractRequest contractRequest = new ContractRequest(id,contractName, requestDate, contractType,
                        reannouncement, newBid);

                contractRequests.add(contractRequest);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            try {
                rs.close();
                st.close();
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return contractRequests;
    }

    public void save(ContractRequest contractRequest) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        String sql = "INSERT INTO CONTRACT_REQUEST(contract_name, request_date, contract_type, " +
                "reannouncement, new_bid) values(?,?,?,?,?)";
        try {
            conn = ds.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, contractRequest.getContractName());
            pstmt.setDate(2, contractRequest.getRequestDate());
            pstmt.setString(3, contractRequest.getContractType());
            pstmt.setLong(4, contractRequest.getReannouncement());
            pstmt.setLong(5, contractRequest.getNewBid());

            pstmt.executeUpdate();
        }catch(SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                pstmt.close();
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
}
