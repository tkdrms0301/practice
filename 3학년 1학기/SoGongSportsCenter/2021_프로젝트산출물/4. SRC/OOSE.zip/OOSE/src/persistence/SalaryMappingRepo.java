package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.SalaryMapping;

public class SalaryMappingRepo {
	private static SalaryMappingRepo instance;
	private static DataSource ds;

	public SalaryMappingRepo() {

	}

	public static SalaryMappingRepo getInstacne() {
		if (instance == null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new SalaryMappingRepo();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instance;
	}

	public void enroll(SalaryMapping salaryMapping) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "INSERT INTO SalaryMapping(employee_id,participatingCode,salaryBudgetCode,payItemCode,paymentOrDeduction,price,projectParticipatingRate,payItem_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, salaryMapping.getEmployee_id());
			pstmt.setString(2, salaryMapping.getParticipatingCode());
			pstmt.setString(3, salaryMapping.getSalaryBudgetCode());
			pstmt.setString(4, salaryMapping.getPayItemCode());
			pstmt.setString(5, salaryMapping.getPaymentOrDeduction());
			pstmt.setInt(6, salaryMapping.getPrice());
			pstmt.setInt(7, salaryMapping.getProjectParticipatingRate());
			pstmt.setInt(8, salaryMapping.getPayItem_id());

			int n = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void delete(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "DELETE FROM salarymapping WHERE mapping_id = ?";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public ArrayList<SalaryMapping> findAll() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = "SELECT  salarymapping.*, employee.name, payitem.itemDetails from salarymapping, employee, payitem where salarymapping.employee_id = employee.employee_id and salarymapping.payItem_id = payitem.payItem_id ORDER BY salarymapping.mapping_id ASC";
		ArrayList<SalaryMapping> salaryMappings = new ArrayList<SalaryMapping>();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				SalaryMapping salaryMapping = new SalaryMapping();
				salaryMapping.setMapping_id(rs.getInt("mapping_id"));
				salaryMapping.setEmployee_id(rs.getInt("employee_id"));
				salaryMapping.setName(rs.getString("name"));
				salaryMapping.setParticipatingCode(rs.getString("participatingCode"));
				salaryMapping.setSalaryBudgetCode(rs.getString("salaryBudgetCode"));
				salaryMapping.setPayItemCode(rs.getString("payItemCode"));
				salaryMapping.setPaymentOrDeduction(rs.getString("paymentOrDeduction"));
				salaryMapping.setPrice(rs.getInt("price"));
				salaryMapping.setProjectParticipatingRate(rs.getInt("projectParticipatingRate"));
				salaryMapping.setPayItem_id(rs.getInt("payItem_id"));
				salaryMapping.setItemDetails(rs.getString("itemDetails"));
				salaryMappings.add(salaryMapping);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return salaryMappings;
	}

	public SalaryMapping findById(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM salarymapping Where mapping_id=?";
		SalaryMapping salaryMapping = new SalaryMapping();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				salaryMapping.setMapping_id(rs.getInt("mapping_id"));
				salaryMapping.setEmployee_id(rs.getInt("employee_id"));
				salaryMapping.setParticipatingCode(rs.getString("participatingCode"));
				salaryMapping.setSalaryBudgetCode(rs.getString("salaryBudgetCode"));
				salaryMapping.setPayItemCode(rs.getString("payItemCode"));
				salaryMapping.setPaymentOrDeduction(rs.getString("paymentOrDeduction"));
				salaryMapping.setPrice(rs.getInt("price"));
				salaryMapping.setProjectParticipatingRate(rs.getInt("projectParticipatingRate"));
				salaryMapping.setPayItem_id(rs.getInt("payItem_id"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return salaryMapping;
	}

	public void update(SalaryMapping salaryMapping) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "UPDATE salarymapping SET mapping_id = ?, participatingCode = ? , salaryBudgetCode = ?, payItemCode = ?, paymentOrDeduction = ?, price = ?,projectParticipatingRate = ?, payItem_id =?, employee_id = ? WHERE mapping_id =? AND payItem_id = ? AND employee_id = ?;";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, salaryMapping.getMapping_id());
			pstmt.setString(2, salaryMapping.getParticipatingCode());
			pstmt.setString(3, salaryMapping.getSalaryBudgetCode());
			pstmt.setString(4, salaryMapping.getPayItemCode());
			pstmt.setString(5, salaryMapping.getPaymentOrDeduction());
			pstmt.setInt(6, salaryMapping.getPrice());
			pstmt.setInt(7, salaryMapping.getProjectParticipatingRate());
			pstmt.setInt(8, salaryMapping.getPayItem_id());
			pstmt.setInt(9, salaryMapping.getEmployee_id());
			pstmt.setInt(10, salaryMapping.getMapping_id());
			pstmt.setInt(11, salaryMapping.getPayItem_id());
			pstmt.setInt(12, salaryMapping.getEmployee_id());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}