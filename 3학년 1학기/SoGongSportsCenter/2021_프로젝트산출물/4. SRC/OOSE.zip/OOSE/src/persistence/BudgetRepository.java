package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


import domain.Budget;

public class BudgetRepository {
	private static BudgetRepository instance;
	private static DataSource ds;
	Connection conn = null;
	Statement stmt = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	private BudgetRepository() {
		
	}
	public static BudgetRepository getInstacne() {
		if(instance==null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new BudgetRepository();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instance;		
	}
	public void save(Budget budget){
		Connection conn = null;
		PreparedStatement pstmt = null; 
		
		String sql = "INSERT INTO BUDGETING(businessCode,employee,approvalType,detail,organizationBudget,executionDetails,approval,reason) values(?,?,?,?,?,?,?,?)";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);	
			pstmt.setInt(1, budget.getBusinessCode());
			pstmt.setString(2, budget.getEmployee());
			pstmt.setString(3, budget.getApprovalType());
			pstmt.setString(4, budget.getDetail());
			pstmt.setInt(5, budget.getOrganizationBudget());
			pstmt.setString(6, budget.getExecutionDetails());
			pstmt.setString(7, budget.getApproval());
			pstmt.setString(8, budget.getReason());
			
			int n = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
	}
	public int deleteBudget(int id){
		String sql="DELETE FROM member where id=?";
		int delete = 0;
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			delete = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		return delete;
	}
	public void updateApproval(int id){
		Connection conn = null;
		PreparedStatement pstmt = null; 
	
		String sql = "UPDATE BUDGETING SET APPROVAL = '����' WHERE id = ? ";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {			
			pstmt = conn.prepareStatement(sql);	

			pstmt.setInt(1, id);
					
			int n = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}	
	}
	public void updateChangeApproval(int id){
		Connection conn = null;
		PreparedStatement pstmt = null; 
	
		String sql = "UPDATE BUDGETING SET APPROVAL = '����',APPROVALTYPE = '����' WHERE id = ? ";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {			
			pstmt = conn.prepareStatement(sql);	

			pstmt.setInt(1, id);
					
			int n = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}	
	}

	public void appoval(Budget budget){
		Connection conn = null;
		PreparedStatement pstmt = null; 
	
		String sql = "UPDATE BUDGETING SET APPROVAL = '����' WHERE businessCode = ? AND employee = ? AND approvalType = ? AND detail = ? AND organizationBudget = ? AND executionDetails = ? ";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {			
			pstmt = conn.prepareStatement(sql);	

			pstmt.setInt(1, budget.getBusinessCode());
			pstmt.setString(2, budget.getEmployee());
			pstmt.setString(3, budget.getApprovalType());
			pstmt.setString(4, budget.getDetail());
			pstmt.setInt(5, budget.getOrganizationBudget());
			pstmt.setString(6, budget.getExecutionDetails());
					
			int n = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}	
	}

	public Budget findByCode(int id){
		Connection conn = null;
		PreparedStatement pstmt = null; 
		ResultSet rs = null;
		Budget budget = new Budget();
		String sql = "SELECT * FROM BUDGETING WHERE id=?";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {			
			pstmt = conn.prepareStatement(sql);			
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			rs.next();
			budget.setId(rs.getInt(1));
			budget.setBusinessCode(rs.getInt(2)); 
			budget.setEmployee(rs.getString(3));
			budget.setApprovalType(rs.getString(4)); 
			budget.setDetail(rs.getString(5));
			budget.setOrganizationBudget(rs.getInt(6));
			budget.setExecutionDetails(rs.getString(7));
			budget.setApproval(rs.getString(8));
			budget.setReason(rs.getString(9));
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}	
		return budget;
	}	
	public Budget findByDetail(String executionDetails){
		Connection conn = null;
		PreparedStatement pstmt = null; 
		ResultSet rs = null;
		Budget budget = new Budget();
		String sql = "SELECT * FROM BUDGETING WHERE executionDetails=?";
		try {
			conn = ds.getConnection();			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {			
			pstmt = conn.prepareStatement(sql);			
			pstmt.setString(1, executionDetails);
			rs = pstmt.executeQuery();	
			if (rs.next() == false) {
				return null;
			}
			rs.next();
			budget.setId(rs.getInt(1));
			budget.setBusinessCode(rs.getInt(2)); 
			budget.setEmployee(rs.getString(3));
			budget.setApprovalType(rs.getString(4)); 
			budget.setDetail(rs.getString(5));
			budget.setOrganizationBudget(rs.getInt(6));
			budget.setExecutionDetails(rs.getString(7));
			budget.setApproval(rs.getString(8));
			budget.setReason(rs.getString(9));
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}	
		return budget;
	}
	public ArrayList<Budget> findAll() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM BUDGETING WHERE APPROVAL = '����'";
		ArrayList<Budget> budgets = new ArrayList<Budget>();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int Id = rs.getInt("id");
				int BusinessCode = rs.getInt("businessCode");
				String Employee = rs.getString("employee");
				String ApprovalType = rs.getString("approvalType");
				String Detail = rs.getString("detail");
				int OrganizationBudget = rs.getInt("organizationBudget");
				String ExecutionDetails = rs.getString("executionDetails");
				String approval = rs.getString("approval");
				String reason = rs.getString("reason");
				Budget budget = new Budget(Id, BusinessCode,Employee, ApprovalType, Detail, OrganizationBudget, ExecutionDetails, approval, reason);
				budgets.add(budget);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}		
		return budgets;
	}

public ArrayList<Budget> findAllApproval() {
	Connection conn = null;
	Statement st = null;
	ResultSet rs = null;
	String sql = "SELECT * FROM BUDGETING WHERE APPROVAL = '����'";
	ArrayList<Budget> budgets = new ArrayList<Budget>();
	try {
		conn = ds.getConnection();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		st = conn.createStatement();
		rs = st.executeQuery(sql);
		while (rs.next()) {
			int Id = rs.getInt("id");
			int BusinessCode = rs.getInt("businessCode");
			String Employee = rs.getString("employee");
			String ApprovalType = rs.getString("approvalType");
			String Detail = rs.getString("detail");
			int OrganizationBudget = rs.getInt("organizationBudget");
			String ExecutionDetails = rs.getString("executionDetails");
			String approval = rs.getString("approval");
			String reason = rs.getString("reason");
			Budget budget = new Budget(Id, BusinessCode,Employee, ApprovalType, Detail, OrganizationBudget, ExecutionDetails, approval, reason);
			budgets.add(budget);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	}		
	return budgets;
}
public ArrayList<Budget> findNonApproval() {
	Connection conn = null;
	Statement st = null;
	ResultSet rs = null;
	String sql = "SELECT * FROM BUDGETING WHERE approvalType = '�����û' AND APPROVAL = '���δ��'";
	ArrayList<Budget> budgets = new ArrayList<Budget>();
	try {
		conn = ds.getConnection();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		st = conn.createStatement();
		rs = st.executeQuery(sql);
		while (rs.next()) {
			int Id = rs.getInt("id");
			int BusinessCode = rs.getInt("businessCode");
			String Employee = rs.getString("employee");
			String ApprovalType = rs.getString("approvalType");
			String Detail = rs.getString("detail");
			int OrganizationBudget = rs.getInt("organizationBudget");
			String ExecutionDetails = rs.getString("executionDetails");
			String approval = rs.getString("approval");
			String reason = rs.getString("reason");
			Budget budget = new Budget(Id, BusinessCode,Employee, ApprovalType, Detail, OrganizationBudget, ExecutionDetails, approval, reason);
			budgets.add(budget);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	}		
	return budgets;
}
public ArrayList<Budget> findNonApprovalChange() {
	Connection conn = null;
	Statement st = null;
	ResultSet rs = null;
	String sql = "SELECT * FROM BUDGETING WHERE approvalType = '�����û' AND APPROVAL = '���δ��'";
	ArrayList<Budget> budgets = new ArrayList<Budget>();
	try {
		conn = ds.getConnection();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		st = conn.createStatement();
		rs = st.executeQuery(sql);
		while (rs.next()) {
			int Id = rs.getInt("id");
			int BusinessCode = rs.getInt("businessCode");
			String Employee = rs.getString("employee");
			String ApprovalType = rs.getString("approvalType");
			String Detail = rs.getString("detail");
			int OrganizationBudget = rs.getInt("organizationBudget");
			String ExecutionDetails = rs.getString("executionDetails");
			String approval = rs.getString("approval");
			String reason = rs.getString("reason");
			Budget budget = new Budget(Id, BusinessCode,Employee, ApprovalType, Detail, OrganizationBudget, ExecutionDetails, approval, reason);
			budgets.add(budget);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally {
		try {
			rs.close();
			st.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	}		
	return budgets;
}

}