package persistence;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.Board;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Connection;

public class BoardRepository {
	ArrayList<Board> list;
	Board dto;
	private static BoardRepository instance;
	private static DataSource ds;

	public BoardRepository() {

	}

	public static BoardRepository getInstacne() {
		if (instance == null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new BoardRepository();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instance;
	}

	public Board read(int employee_id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM employee1 WHERE id=?";
		Board board = new Board();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, employee_id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				board.setEmployee_id(rs.getLong(1));
				board.setName(rs.getString(2));
				board.setPhone_number(rs.getString(3));
				board.setPosition(rs.getString(4));
				board.setEmployee_classification(rs.getString(5));
				board.setAffiliation(rs.getString(6));
				board.setAge(rs.getInt(7));
				board.setGender(rs.getString(8));
				board.setWorking_status(rs.getString(9));
				board.setAssignment(rs.getString(10));
				board.setEducation(rs.getString(11));
				board.setMajor(rs.getString(12));
				board.setDisabled(rs.getString(13));
				board.setRewarding_patriotism(rs.getString(14));
				board.setSalary_peak(rs.getString(15));
				board.setRecruitment(rs.getString(16));
				board.setEntered_date(rs.getInt(17));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
				else if (rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return board;
	}

	public void write(Board data) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO employee1(name, phone_number, position, employee_classification, affiliation, age, gender, working_status, assignment,"
				+ "education, major, disabled, rewarding_patriotism, salary_peak, recruitment, entered_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);			
			pstmt.setString(1, data.getName());
			pstmt.setString(2, data.getPhone_number());
			pstmt.setString(3, data.getPosition());
			pstmt.setString(4, data.getEmployee_classification());
			pstmt.setString(5, data.getAffiliation());
			pstmt.setInt(6, data.getAge());
			pstmt.setString(7, data.getGender());
			pstmt.setString(8, data.getWorking_status());
			pstmt.setString(9, data.getAssignment());
			pstmt.setString(10, data.getEducation());
			pstmt.setString(11, data.getMajor());
			pstmt.setString(12, data.getDisabled());
			pstmt.setString(13, data.getRewarding_patriotism());
			pstmt.setString(14, data.getSalary_peak());
			pstmt.setString(15, data.getRecruitment());
			pstmt.setInt(16, data.getEntered_date());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void update(Board data) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE employee1 SET name=?,phone_number=?,position=?,employee_classification=?,affiliation=?,age=?,gender=?,"
				+ "working_status=?,assignment=?,education=?,major=?,disabled=?,rewarding_patriotism=?,salary_peak=?,recruitment=?,"
				+ "entered_date=? WHERE employee_id=?";

		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);			
			pstmt.setString(1, data.getName());
			pstmt.setString(2, data.getPhone_number());
			pstmt.setString(3, data.getPosition());
			pstmt.setString(4, data.getEmployee_classification());
			pstmt.setString(5, data.getAffiliation());
			pstmt.setInt(6, data.getAge());
			pstmt.setString(7, data.getGender());
			pstmt.setString(8, data.getWorking_status());
			pstmt.setString(9, data.getAssignment());
			pstmt.setString(10, data.getEducation());
			pstmt.setString(11, data.getMajor());
			pstmt.setString(12, data.getDisabled());
			pstmt.setString(13, data.getRewarding_patriotism());
			pstmt.setString(14, data.getSalary_peak());
			pstmt.setString(15, data.getRecruitment());
			pstmt.setInt(16, data.getEntered_date());
			pstmt.setLong(17, data.getEmployee_id());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void delete(Board data) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "DELETE FROM employee1 where employee_id=?;";

		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setLong(1, data.getEmployee_id());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public Board findById(Long employee_id) {
		return null;
	}

	public ArrayList<Board> findAll() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM employee1";
		ArrayList<Board> boards = new ArrayList<Board>();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				Long employee_id = rs.getLong("employee_id");
				String name = rs.getString("name");
				String phone_number = rs.getString("phone_number");
				String position = rs.getString("position");
				String employee_classification = rs.getString("employee_classification");
				String affiliation = rs.getString("affiliation");
				int age = rs.getInt("age");
				String gender = rs.getString("gender");
				String working_status = rs.getString("working_status");
				String assignment = rs.getString("assignment");
				String education = rs.getString("education");
				String major = rs.getString("major");
				String disabled = rs.getString("disabled");
				String rewarding_patriotism = rs.getString("rewarding_patriotism");
				String salary_peak = rs.getString("salary_peak");
				String recruitment = rs.getString("recruitment");
				int entered_date = rs.getInt("entered_date");
				
				Board posts = new Board(employee_id, name, phone_number, position, employee_classification, affiliation, age, gender, working_status, assignment, 
						education, major, disabled, rewarding_patriotism, salary_peak, recruitment, entered_date);
				boards.add(posts);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return boards;
	}
}
