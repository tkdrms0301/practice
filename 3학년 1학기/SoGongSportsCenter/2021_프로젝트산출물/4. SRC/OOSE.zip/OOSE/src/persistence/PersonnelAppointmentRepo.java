package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.Career;
import domain.PersonnelAppointment;

public class PersonnelAppointmentRepo {
	private static PersonnelAppointmentRepo instance;
	private static DataSource ds;
	public PersonnelAppointmentRepo() {
		
	}
	public static PersonnelAppointmentRepo getInstacne() {
		if(instance==null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new PersonnelAppointmentRepo();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instance;		
	}
	
	public void enroll(PersonnelAppointment personnelAppointment){
		Connection conn = null;
		PreparedStatement pstmt = null; 
		
		String sql = "INSERT INTO personnel_appointment (employee_id,division,position,name,department,personnel_appointment,remarks) VALUES (?, ?, ?, ?, ?, ?, ?);";
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);			
			
			pstmt.setInt(1, personnelAppointment.getEmployee_id());
			pstmt.setString(2, personnelAppointment.getDivision());
			pstmt.setString(3, personnelAppointment.getPosition());
			pstmt.setString(4, personnelAppointment.getName());
			pstmt.setString(5, personnelAppointment.getDepartment());
			pstmt.setString(6, personnelAppointment.getPersonnel_appointment());
			pstmt.setString(7, personnelAppointment.getRemarks());
			
			int n = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
	}
	public ArrayList<PersonnelAppointment> findAll()
	{
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM personnel_appointment;";
		ArrayList<PersonnelAppointment> personnelAppointments = new ArrayList<PersonnelAppointment>();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				PersonnelAppointment personnelAppointment = new PersonnelAppointment();
				
				personnelAppointment.setPersonnel_appointment_id(rs.getInt("personnel_appointment_id"));
				personnelAppointment.setEmployee_id(rs.getInt("employee_id"));
				personnelAppointment.setDivision(rs.getString("division"));
				personnelAppointment.setPosition(rs.getString("position"));
				personnelAppointment.setName(rs.getString("name"));
				personnelAppointment.setDepartment(rs.getString("department"));
				personnelAppointment.setPersonnel_appointment(rs.getString("personnel_appointment"));
				personnelAppointment.setRemarks(rs.getString("remarks"));

				personnelAppointments.add(personnelAppointment);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}		
		return personnelAppointments;	
	}
	public Career findById(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null; 
		ResultSet rs = null;
		String sql = "SELECT  career.Jop_experience From career Where Employee_employee_id=?";
		Career career = new Career();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				career.setJop_experience(rs.getString("Jop_experience"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}		
		return career;
	}
}