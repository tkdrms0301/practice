package persistence;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.LeaveOfAbsence;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.sql.Connection;

public class LOARepository {
	ArrayList<LeaveOfAbsence> list;
	LeaveOfAbsence dto;
	private static LOARepository instance;
	private static DataSource ds;

	public LOARepository() {

	}

	public static LOARepository getInstacne() {
		if (instance == null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new LOARepository();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instance;
	}

	
	public void write(LeaveOfAbsence data) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE leave_of_absence SET leaveSignificant=? WHERE leave_of_absence_id=?";

		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, data.getLeaveSignificant());
			pstmt.setInt(2, data.getLeave_of_absence_id());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void update(LeaveOfAbsence data) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE leave_of_absence SET leaveSignificant=? WHERE leave_of_absence_id=?;";

		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, data.getLeaveSignificant());
			pstmt.setInt(2, data.getLeave_of_absence_id());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public LeaveOfAbsence read(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT leaveSignificant FROM Leave_of_absence WHERE leave_of_absence_id=?";
		LeaveOfAbsence loa = new LeaveOfAbsence();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			rs.next();
			loa.setLeave_of_absence_id(id);
			loa.setLeaveSignificant(rs.getString(1));
		} catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
				else if (rs != null)
					rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return loa;
	}

	public ArrayList<LeaveOfAbsence> findAll() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM leave_of_absence";
		ArrayList<LeaveOfAbsence> loas = new ArrayList<LeaveOfAbsence>();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int leave_of_absence_id = rs.getInt("leave_of_absence_id");
				String name = rs.getString("name");
				String position = rs.getString("position");
				String department = rs.getString("department");
				int leaveState = rs.getInt("leaveState");
				Date startPeriodDay = rs.getDate("startPeriodDay");
				Date endPeriodDay = rs.getDate("endPeriodDay");
				String leaveReason = rs.getString("leaveReason");
				String leaveSignificant = rs.getString("leaveSignificant");
				LeaveOfAbsence loa_info = new LeaveOfAbsence(leave_of_absence_id, name, position, department, leaveState, startPeriodDay, endPeriodDay, leaveReason, leaveSignificant);
				loas.add(loa_info);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return loas;
	}
	
	public ArrayList<LeaveOfAbsence> findPeriod(LeaveOfAbsence data) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM leave_of_absence  WHERE (endPeriodDay <= ? OR endPeriodDay IS NULL) AND startPeriodDay BETWEEN ? AND ? ORDER BY leave_of_absence_id;";
		ArrayList<LeaveOfAbsence> loas = new ArrayList<LeaveOfAbsence>();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			Date date = new Date();
	        long timeInMilliSeconds = data.getEndPeriodDay().getTime();
	        java.sql.Date ep = new java.sql.Date(timeInMilliSeconds);
	        long timeInMilliSeconds2 = data.getStartPeriodDay().getTime();
	        java.sql.Date sp = new java.sql.Date(timeInMilliSeconds2);
	        java.sql.Date ep2 = ep;
			pstmt.setDate(1, ep);
			pstmt.setDate(2, sp);
			pstmt.setDate(3, ep2);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				int leave_of_absence_id = rs.getInt("leave_of_absence_id");
				String name = rs.getString("name");
				String position = rs.getString("position");
				String department = rs.getString("department");
				int leaveState = rs.getInt("leaveState");
				Date startPeriodDay = rs.getDate("startPeriodDay");
				Date endPeriodDay = rs.getDate("endPeriodDay");
				String leaveReason = rs.getString("leaveReason");
				String leaveSignificant = rs.getString("leaveSignificant");
				LeaveOfAbsence loa_info = new LeaveOfAbsence(leave_of_absence_id, name, position, department, leaveState, startPeriodDay, endPeriodDay, leaveReason, leaveSignificant);
				loas.add(loa_info);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
				else if (pstmt != null)
					pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return loas;
	}

}
