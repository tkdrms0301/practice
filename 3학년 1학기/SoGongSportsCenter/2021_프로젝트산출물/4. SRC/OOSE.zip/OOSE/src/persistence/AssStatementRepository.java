package persistence;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.AssStatement;

import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.sql.Connection;

public class AssStatementRepository {
	ArrayList<AssStatement> list;
	AssStatement dto;
	private static AssStatementRepository instance;
	private static DataSource ds;

	public AssStatementRepository() {

	}

	public static AssStatementRepository getInstacne() {
		if (instance == null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new AssStatementRepository();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instance;
	}


	public ArrayList<AssStatement> findAll() {
		System.out.print("---------------");
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM assstatement";
		ArrayList<AssStatement> ast = new ArrayList<AssStatement>();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				int assets_number = rs.getInt("assets_number");
				System.out.println("test : " + assets_number);
				String assets_name = rs.getString("assets_name");
				String price = rs.getString("price");
				String amount = rs.getString("amount");
				//LocalDateTime regdate = rs.getTimestamp("regdate").toLocalDateTime();
				String due_return = rs.getString("due_return");
				String partname = rs.getString("partname");
				AssStatement ass = new AssStatement(assets_number, assets_name, price, amount, due_return, partname);
				ast.add(ass);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return ast;
	}
}
