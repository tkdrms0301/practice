package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.Career;
import domain.PayItem;

public class PayItemRepo {

	private static PayItemRepo instance;
	private static DataSource ds;

	public PayItemRepo() {
			
		}

	public static PayItemRepo getInstacne() {
		if (instance == null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new PayItemRepo();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return instance;
	}

	public ArrayList<PayItem> findAll() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = "SELECT  * FROM payitem;";
		ArrayList<PayItem> payItems = new ArrayList<PayItem>();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				PayItem payItem = new PayItem();
				payItem.setPayItem_id(rs.getInt("payItem_id"));
				payItem.setPaymentOrDeduction(rs.getString("paymentOrDeduction"));
				payItem.setSalaryBudgetCode(rs.getString("salaryBudgetCode"));
				payItem.setPayItemCode(rs.getString("payItemCode"));
				payItem.setPrice(rs.getInt("price"));
				payItem.setItemDetails(rs.getString("itemDetails"));
				payItems.add(payItem);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				st.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return payItems;
	}

	public PayItem findById(int id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM payitem Where Employee_employee_id=?";
		PayItem payItem = new PayItem();
		try {
			conn = ds.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				payItem.setPayItem_id(rs.getInt("payItem_id"));
				payItem.setPaymentOrDeduction(rs.getString("paymentOrDeduction"));
				payItem.setSalaryBudgetCode(rs.getString("salaryBudgetCode"));
				payItem.setPayItemCode(rs.getString("payItemCode"));
				payItem.setPrice(rs.getInt("price"));
				payItem.setItemDetails(rs.getString("itemDetails"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return payItem;
	}

	
}
