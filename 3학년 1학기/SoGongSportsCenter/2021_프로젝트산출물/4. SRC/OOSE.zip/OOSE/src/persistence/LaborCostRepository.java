package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import domain.Employee;
import domain.LaborCost;

public class LaborCostRepository {
	private static LaborCostRepository instance;
	private static DataSource ds;

	public static LaborCostRepository getInstance() {
		if (instance == null) {
			try {
				Context context = new InitialContext();
				ds = (DataSource) context.lookup("java:comp/env/jdbc/MySQL");
				return instance = new LaborCostRepository();
			} catch (NamingException e) {
				e.printStackTrace();
			}
		}
		return instance;
	}

	public ArrayList<LaborCost> findAll() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM laborcost, employee WHERE isRemoved=0 and laborcost.employee_id = employee.employee_id";
		ArrayList<LaborCost> datas = new ArrayList<LaborCost>();
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				LaborCost cost = new LaborCost();
				Employee employee = new Employee();
				int laborcost_id = rs.getInt("laborcost.laborcost_id");
				int employee_id = rs.getInt("employee_id");
				String employee_name = rs.getString("employee.name");
				int employee_position = rs.getInt("employee.position");
				String payment = rs.getString("laborcost.payment");
				LocalDateTime date = rs.getTimestamp("laborcost.date").toLocalDateTime();
				
				employee.setName(employee_name);
				employee.setPosition(employee_position);
				cost.setEmployee_id(employee_id);
				cost.setLaborcost_id(laborcost_id);
				cost.setPayment(payment);
				cost.setDate(date);
				cost.setEmployee(employee);

				datas.add(cost);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return datas;
	}
}
