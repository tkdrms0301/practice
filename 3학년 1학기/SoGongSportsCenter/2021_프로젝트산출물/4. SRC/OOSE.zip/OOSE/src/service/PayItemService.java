package service;

import java.util.ArrayList;

import domain.PayItem;
import persistence.PayItemRepo;

public class PayItemService {
	private final PayItemRepo payItemRepo = PayItemRepo.getInstacne();
	
	public PayItemService() {}
	
	public ArrayList<PayItem> findAll()
	{
		return payItemRepo.findAll();
	}
	public PayItem findById(int id) {
		return payItemRepo.findById(id);
	}
}
