package service;

import java.util.ArrayList;

import domain.SalaryMapping;
import persistence.SalaryMappingRepo;

public class SalaryMappingService {
	private final SalaryMappingRepo salaryMappingRepo = SalaryMappingRepo.getInstacne();
	
	public SalaryMappingService() {}
	
	public void insert(SalaryMapping salaryMapping)
	{
		salaryMappingRepo.enroll(salaryMapping);
	}
	public ArrayList<SalaryMapping> findAll()
	{
		return salaryMappingRepo.findAll();
	}
	public SalaryMapping findById(int id) {
		return salaryMappingRepo.findById(id);
	}

	public void update(SalaryMapping salaryMapping) {
		salaryMappingRepo.update(salaryMapping);
	}
	public void delete(int id) {
		salaryMappingRepo.delete(id);
	}
}
