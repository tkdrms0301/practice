package service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.management.RuntimeErrorException;

import domain.Asset;
import persistence.AssetRepository;


public class AssetService {
	private final AssetRepository AssetsRepository = AssetRepository.getInstacne();
	private Asset statetments;
	public AssetService() {
		
	}
	public Asset read(int id) {		
		return AssetRepository.read(id);  
	}
	public void write(Asset data) {		
		new AssetRepository().write(data);
	}
	public void update(Asset data) {		
		new AssetRepository().update(data);
	}
	public ArrayList<Asset> findAssets() {
		return AssetsRepository.findAll();
	}
}

