package service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.management.RuntimeErrorException;

import domain.Budget;
import persistence.BudgetRepository;


public class BudgetService {
	private final BudgetRepository budgetRepository = BudgetRepository.getInstacne();
	public BudgetService() {
		
	}
	public void join(Budget budget) {
		validateDuplicateBudget(budget);
		budgetRepository.save(budget);        
	}
	public void join2(Budget budget) {
		//validateDuplicateBudget(budget);
		budgetRepository.save(budget);        
	}
	public void approval(Budget budget) {
		budgetRepository.appoval(budget);       
	}
	public void updateApproval(int id) {
		budgetRepository.updateApproval(id);       
	}
	public void updateChangeApproval(int id) {
		budgetRepository.updateChangeApproval(id);       
	}
	private void validateDuplicateBudget(Budget budget){
		Budget findBudget = budgetRepository.findByDetail(budget.getExecutionDetails());
        if(findBudget!=null){
        	throw new IllegalArgumentException("�ߺ�.");
        }
    }
	public ArrayList<Budget> findBudgets() {
        return budgetRepository.findAll();
    }
	public ArrayList<Budget> findAllBudgets() {
        return budgetRepository.findAllApproval();
    }
	public ArrayList<Budget> findNonApprovalBudgets() {
        return budgetRepository.findNonApproval();
    }
	public ArrayList<Budget> findNonApprovalChange() {
        return budgetRepository.findNonApprovalChange();
    }
	
}
