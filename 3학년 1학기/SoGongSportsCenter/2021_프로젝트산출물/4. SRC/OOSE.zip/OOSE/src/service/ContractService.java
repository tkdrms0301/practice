package service;

import domain.Contract;
import persistence.ContractRepository;

import java.util.ArrayList;

public class ContractService {

    private final ContractRepository contractRepository = ContractRepository.getInstance();

    public ContractService() {

    }

    public ArrayList<Contract> findContracts() {
        return contractRepository.findAll();
    }

    public void write(Contract contract) {
        contractRepository.save(contract);
    }

    public void update(Contract contract) {
        contractRepository.update(contract);
    }

    public Contract findContractById(String contractId) {
        return contractRepository.findById(contractId);
    }
}
