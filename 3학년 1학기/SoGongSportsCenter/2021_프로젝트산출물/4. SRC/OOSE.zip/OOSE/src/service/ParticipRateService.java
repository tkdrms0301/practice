package service;

import java.util.ArrayList;

import domain.ParticipRate;
import persistence.ParticipRateRepository;

public class ParticipRateService {
	private final ParticipRateRepository participrateRepository = ParticipRateRepository.getInstacne();

	public ParticipRateService() {

	}

	public void insert(ParticipRate rate) {
		participrateRepository.insert(rate);
	}

	public void update(ParticipRate rate) {
		participrateRepository.update(rate);
	}

	public void delete(ParticipRate rate) {
		participrateRepository.delete(rate);
	}

	public ArrayList<ParticipRate> findAll() {
		return participrateRepository.findAll();
	}

}
