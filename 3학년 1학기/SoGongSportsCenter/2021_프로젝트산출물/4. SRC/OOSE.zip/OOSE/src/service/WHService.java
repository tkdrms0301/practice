package service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.management.RuntimeErrorException;

import domain.LeaveOfAbsence;
import domain.WorkingHours;
import persistence.LOARepository;
import persistence.WHRepository;

public class WHService {
	private final static WHRepository whRepository = WHRepository.getInstacne();
	private WorkingHours wh;
	public WHService() {
		
	}
	
	public static void daySet(WorkingHours data) {		
		new WHRepository().daySet(data);
	}
	
	public static void timeSet(WorkingHours data) {		
		new WHRepository().timeSet(data);
	}

}
