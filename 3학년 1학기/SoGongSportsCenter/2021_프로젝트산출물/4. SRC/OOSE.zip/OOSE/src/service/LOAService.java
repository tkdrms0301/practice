package service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.management.RuntimeErrorException;

import domain.LeaveOfAbsence;
import persistence.LOARepository;

public class LOAService {
	private final static LOARepository loaRepository = LOARepository.getInstacne();
	private LeaveOfAbsence loa;
	public LOAService() {
		
	}
	
	public static LeaveOfAbsence read(int id) {		
		return loaRepository.read(id);  
	}
	
	public void update(LeaveOfAbsence data) {		
		new LOARepository().update(data);
	}
	
	public static void write(LeaveOfAbsence data) {		
		new LOARepository().write(data);
	}
	
	public ArrayList<LeaveOfAbsence> findBoards() {
		return loaRepository.findAll();
	}
	
	public static ArrayList<LeaveOfAbsence> periodFindBoards(LeaveOfAbsence data) {
		return loaRepository.findPeriod(data);
	}
}
