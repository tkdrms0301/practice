package service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.management.RuntimeErrorException;

import domain.Permission;
import persistence.PermissionRepository;

public class PermissionService {
	private final PermissionRepository PermissionsRepository = PermissionRepository.getInstacne();
	private Permission statetments;
	public PermissionService() {
		
	}
	public ArrayList<Permission> findPermissions() {
		return PermissionsRepository.findAll();
	}
}
