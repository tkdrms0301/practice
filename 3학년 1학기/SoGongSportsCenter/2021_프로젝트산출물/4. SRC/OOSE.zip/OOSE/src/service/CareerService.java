package service;

import java.util.ArrayList;

import domain.Career;
import persistence.CareerRepo;

public class CareerService {
	private final CareerRepo careerRepo = CareerRepo.getInstacne();
	
	public CareerService() {}
	
	public void insert(Career dto)
	{
		careerRepo.enroll(dto);
	}
	public ArrayList<Career> findAll()
	{
		return careerRepo.findAll();
	}
	public Career findById(int id) {
		return careerRepo.findById(id);
	}

	public void update(Career career) {
		careerRepo.update(career);
	}
}
