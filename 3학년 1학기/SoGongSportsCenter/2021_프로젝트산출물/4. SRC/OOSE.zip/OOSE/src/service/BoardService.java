package service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.management.RuntimeErrorException;

import domain.Board;
import persistence.BoardRepository;

public class BoardService {
	private final BoardRepository boardRepository = BoardRepository.getInstacne();
	private Board board;
	public BoardService() {
		
	}
	public Board read(int employee_id) {		
		return boardRepository.read(employee_id);  
	}
	public void write(Board data) {		
		new BoardRepository().write(data);
	}
	public void update(Board data) {		
		new BoardRepository().update(data);
	}
	public void delete(Board data) {		
		new BoardRepository().delete(data); 
	}
	public ArrayList<Board> findBoards() {
		return boardRepository.findAll();
	}
}
