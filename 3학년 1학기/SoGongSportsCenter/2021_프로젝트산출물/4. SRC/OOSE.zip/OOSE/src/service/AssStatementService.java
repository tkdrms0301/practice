package service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.management.RuntimeErrorException;

import domain.AssStatement;
import persistence.AssStatementRepository;

public class AssStatementService {
	private final AssStatementRepository AssStatementsRepository = AssStatementRepository.getInstacne();
	private AssStatement statetments;
	public AssStatementService() {
		
	}
	public ArrayList<AssStatement> findAssStatements() {
		return AssStatementsRepository.findAll();
	}
}
