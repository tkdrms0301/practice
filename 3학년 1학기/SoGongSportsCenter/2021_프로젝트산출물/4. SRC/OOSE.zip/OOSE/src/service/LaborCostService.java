package service;

import java.util.ArrayList;

import domain.LaborCost;
import persistence.LaborCostRepository;

public class LaborCostService {

	private final LaborCostRepository laborcostRepository = LaborCostRepository.getInstance();

	public LaborCostService() {

	}

	public ArrayList<LaborCost> findAll() {
		return laborcostRepository.findAll();
	}
}
