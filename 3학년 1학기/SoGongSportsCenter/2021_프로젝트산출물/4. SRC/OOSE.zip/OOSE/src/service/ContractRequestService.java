package service;

import domain.ContractRequest;
import persistence.ContractRepository;
import persistence.ContractRequestRepository;

import java.util.ArrayList;

public class ContractRequestService {

    private final ContractRequestRepository contractRequestRepository = ContractRequestRepository.getInstance();

    public ContractRequestService() {

    }

    public ArrayList<ContractRequest> findContractRequests() {
        return contractRequestRepository.findAll();
    }

    public void write(ContractRequest contractRequest) {
        contractRequestRepository.save(contractRequest);
    }
}
