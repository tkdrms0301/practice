package service;

import java.util.ArrayList;

import domain.Career;
import domain.PersonnelAppointment;
import persistence.PersonnelAppointmentRepo;

public class PersonnelAppointmentService {
	private final PersonnelAppointmentRepo personnelAppointmentRepo = PersonnelAppointmentRepo.getInstacne();
	
	public PersonnelAppointmentService() {}
	
	public void insert(PersonnelAppointment dto)
	{
		personnelAppointmentRepo.enroll(dto);
	}
	public ArrayList<PersonnelAppointment> findAll()
	{
		return personnelAppointmentRepo.findAll();
	}
}
