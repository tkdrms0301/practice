package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Asset;
import service.AssetService;

public class AssetController implements Controller{

	private final AssetService AssetService = new AssetService();
	private String ass_name;
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		if(url.equals("/Asset/Asset-list")) {
			ArrayList<Asset> at = AssetService.findAssets();
			modelAndView.setViewName("/Asset/Asset-list");
			modelAndView.getModel().put("Asset", at);
		}
		
		
		else if(url.equals("/Asset/Asset-detail")) {
			int id = Integer.parseInt(request.getParameter("id"));
			Asset Asset = AssetService.read(id);
			modelAndView.setViewName("Asset/Asset-detail");
			modelAndView.getModel().put("Asset", Asset);
		}
		else if(url.equals("/Asset/Asset-write")) {
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("Asset/Asset-write");
			}
			else if(request.getMethod().equals("POST")) {
				Asset Asset = new Asset();
				Asset.setAss_name(request.getParameter("ass_name"));
				Asset.setLoss(request.getParameter("loss"));
				Asset.setSell(request.getParameter("sell"));
				AssetService.write(Asset);

				modelAndView.setViewName("index");
				
				
			}
		}
		else if(url.equals("/Asset/Asset-update")) {
			if(request.getMethod().equals("GET")) {
				int id = Integer.parseInt(request.getParameter("id"));
				Asset Asset = AssetService.read(id);
				
				modelAndView.getModel().put("Asset", Asset);
				modelAndView.setViewName("Asset/Asset-update");
			}
			else if(request.getMethod().equals("POST")) {
				Asset Asset = new Asset();
				//int ass_number = int.parseInt(request.getParameter("ass_number"));
				Asset.setAss_name(ass_name);
				Asset.setLoss(request.getParameter("loss"));
				Asset.setSell(request.getParameter("sell"));
				AssetService.update(Asset);
				modelAndView.setViewName("index");
				
			}
		
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
	}
		return modelAndView;
}
	
	
	
	


}