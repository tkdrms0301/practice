package controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.PayItem;
import domain.SalaryMapping;
import service.SalaryMappingService;

public class SalaryMappingController implements Controller{
	private final SalaryMappingService salaryMappingService = new SalaryMappingService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ModelAndView modelAndView = new ModelAndView();
		
		if(url.equals("/SalaryMapping/Enroll")) {
			if(request.getMethod().equals("GET")) {
				if(request.getParameterValues("payitems")==null) {
					modelAndView.setViewName("/SalaryMapping/Enroll");
				}
				else {
					String [] str = request.getParameterValues("payitems");
					PayItem payitem = new PayItem();
					payitem.setPayItem_id(Integer.parseInt(str[0]));
					payitem.setSalaryBudgetCode((str[1]));
					payitem.setPayItemCode((str[2]));
					payitem.setPaymentOrDeduction((str[3]));
					payitem.setItemDetails((str[4]));
					payitem.setPrice(Integer.parseInt(str[5]));
					modelAndView.setViewName("/SalaryMapping/Enroll");
					modelAndView.getModel().put("payItem", payitem);
				}
			}
			else if(request.getMethod().equals("POST")) {
				SalaryMapping salaryMapping = new SalaryMapping();
				salaryMapping.setEmployee_id(Integer.parseInt(request.getParameter("employee_id")));
				salaryMapping.setParticipatingCode(request.getParameter("participatingCode"));
				salaryMapping.setSalaryBudgetCode(request.getParameter("salaryBudgetCode"));
				salaryMapping.setPayItemCode(request.getParameter("payItemCode"));
				salaryMapping.setPaymentOrDeduction(request.getParameter("paymentOrDeduction"));
				salaryMapping.setPrice(Integer.parseInt(request.getParameter("price")));
				salaryMapping.setProjectParticipatingRate(Integer.parseInt(request.getParameter("projectParticipatingRate")));
				salaryMapping.setPayItem_id(Integer.parseInt(request.getParameter("payItem_id")));
				salaryMappingService.insert(salaryMapping);	
				modelAndView.setViewName("index");
			}
		}
		else if(url.equals("/SalaryMapping/Update")) {
			if(request.getMethod().equals("GET")) {
		
				if(request.getParameterValues("payitems")==null) {
					if(request.getParameterValues("salaryMappings")==null) {
						System.out.println("����");
						modelAndView.setViewName("index");
					}
					else {
						String [] str = request.getParameterValues("salaryMappings");
						SalaryMapping salaryMapping = salaryMappingService.findById(Integer.parseInt(str[0]));
						salaryMapping.setName(str[2]);
						salaryMapping.setItemDetails(str[7]);
						salaryMapping.setProjectParticipatingRate(Integer.parseInt(str[9]));
						
						PayItem payitem = new PayItem();
						payitem.setPayItem_id(salaryMapping.getPayItem_id());
						payitem.setSalaryBudgetCode(salaryMapping.getSalaryBudgetCode());
						payitem.setPayItemCode(salaryMapping.getPayItemCode());
						payitem.setPaymentOrDeduction(salaryMapping.getPaymentOrDeduction());
						payitem.setItemDetails(salaryMapping.getItemDetails());
						payitem.setPrice(salaryMapping.getPrice());
						modelAndView.setViewName("/SalaryMapping/Update");
						modelAndView.getModel().put("payItem", payitem);
						modelAndView.getModel().put("salaryMapping", salaryMapping);
					}
				}
				else {
					String [] str = request.getParameterValues("payitems");
					PayItem payitem = new PayItem();
					payitem.setPayItem_id(Integer.parseInt(str[0]));
					payitem.setSalaryBudgetCode((str[1]));
					payitem.setPayItemCode((str[2]));
					payitem.setPaymentOrDeduction((str[3]));
					payitem.setItemDetails((str[4]));
					payitem.setPrice(Integer.parseInt(str[5]));
					modelAndView.setViewName("/SalaryMapping/Update");
					modelAndView.getModel().put("payItem", payitem);
				}
				
			}
			else if(request.getMethod().equals("POST")) {
				SalaryMapping salaryMapping = new SalaryMapping();
				salaryMapping.setMapping_id(Integer.parseInt(request.getParameter("mapping_id")));
				salaryMapping.setEmployee_id(Integer.parseInt(request.getParameter("employee_id")));
				salaryMapping.setParticipatingCode(request.getParameter("participatingCode"));
				salaryMapping.setSalaryBudgetCode(request.getParameter("salaryBudgetCode"));
				salaryMapping.setPayItemCode(request.getParameter("payItemCode"));
				salaryMapping.setPaymentOrDeduction(request.getParameter("paymentOrDeduction"));
				salaryMapping.setPrice(Integer.parseInt(request.getParameter("price")));
				salaryMapping.setProjectParticipatingRate(Integer.parseInt(request.getParameter("projectParticipatingRate")));
				salaryMapping.setPayItem_id(Integer.parseInt(request.getParameter("payItem_id")));
				salaryMappingService.update(salaryMapping);
				modelAndView.setViewName("index");
			}
		}
		else if(url.equals("/SalaryMapping/Display")) {
			if(request.getMethod().equals("GET")) {
				ArrayList<SalaryMapping> salaryMappings = salaryMappingService.findAll();
				modelAndView.setViewName("/SalaryMapping/Display");
				modelAndView.getModel().put("salaryMappings", salaryMappings);
			}
			else if(request.getMethod().equals("POST")) {
				String str[]=request.getParameterValues("salaryMappings");
				int mapping_id=Integer.parseInt(str[0]);
				salaryMappingService.delete(mapping_id);
				modelAndView.setViewName("index");
			}
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}

}
