package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.PayItem;
import service.PayItemService;

public class PayItemController implements Controller {
	private final PayItemService payItemService = new PayItemService();

	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ModelAndView modelAndView = new ModelAndView();

		if (url.equals("/PayItem/Display")) {
			String type = request.getParameter("type");
			ArrayList<PayItem> payItems = payItemService.findAll();
			modelAndView.setViewName("/PayItem/Display");
			modelAndView.getModel().put("payItems", payItems);
			modelAndView.getModel().put("type", type);

		} else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}

}
