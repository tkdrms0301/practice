package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Budget;
import service.BudgetService;

public class BudgetController implements Controller{
	
	private final BudgetService budgetService = new BudgetService();

	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		
		if(url.equals("/budget/enroll")) { 		//�����û
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("/budget/enroll");
			}	
			
			else if(request.getMethod().equals("POST")) {
				Budget budget = new Budget();
				budget.setBusinessCode(Integer.parseInt(request.getParameter("businessCode")));
				budget.setEmployee(request.getParameter("employee"));
				budget.setApprovalType("�����û");
				budget.setDetail(request.getParameter("detail"));
				budget.setOrganizationBudget(Integer.parseInt(request.getParameter("organizationBudget")));
				budget.setExecutionDetails(request.getParameter("executionDetails"));
				budget.setApproval("���δ��");
				budget.setReason(null);
				//budget.setReason(request.getParameter("reason"));
				budgetService.join(budget);
				modelAndView.setViewName("index");
			}
		}
		if(url.equals("/budget/approval-page")) { 		//�����û����
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("/budget/approval-page");
			}	
			else if(request.getMethod().equals("POST")) {
				int id = Integer.parseInt(request.getParameter("id"));
				//budget.setReason(request.getParameter("reason"));
				//budgetService.join(budget);
				budgetService.updateApproval(id);
				modelAndView.setViewName("index");
			}
		}
		if(url.equals("/budget/capproval-page")) { 		//���꺯�����
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("/budget/capproval-page");
			}	
			else if(request.getMethod().equals("POST")) {
				int id = Integer.parseInt(request.getParameter("id"));
				//budget.setReason(request.getParameter("reason"));
				//budgetService.join(budget);
				budgetService.updateApproval(id);
				modelAndView.setViewName("index");
			}
		}
		if(url.equals("/budget/change-page")) { 			//���꺯���û
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("/budget/change-page");
			}	
			
			else if(request.getMethod().equals("POST")) {
				int id = Integer.parseInt(request.getParameter("id"));
				budgetService.updateChangeApproval(id);
				Budget budget = new Budget();
				budget.setBusinessCode(Integer.parseInt(request.getParameter("businessCode")));
				budget.setEmployee(request.getParameter("employee"));
				budget.setApprovalType("�����û");
				budget.setDetail(request.getParameter("detail"));
				budget.setOrganizationBudget(Integer.parseInt(request.getParameter("organizationBudget")));
				budget.setExecutionDetails(request.getParameter("executionDetails"));
				budget.setApproval("���δ��");
				budget.setReason(request.getParameter("reason"));
				budgetService.join2(budget);
				modelAndView.setViewName("index");
			}
		}
		else if(url.equals("/budget/approval")){		//�����û���
			ArrayList<Budget> budgets = budgetService.findNonApprovalBudgets();
			request.setAttribute("budgets", budgets);
			modelAndView.setViewName("/budget/approval");
		}
		else if(url.equals("/budget/capproval")){		//���꺯���û���
			ArrayList<Budget> budgets = budgetService.findNonApprovalChange();
			request.setAttribute("budgets", budgets);
			modelAndView.setViewName("/budget/capproval");
		}
		else if(url.equals("/budget/change")){		//���꺯���û���
			ArrayList<Budget> budgets = budgetService.findAllBudgets();
			request.setAttribute("budgets", budgets);
			modelAndView.setViewName("/budget/change");
		}
		else if(url.equals("/budget/budgets")){			//���θ����ȸ
				ArrayList<Budget> budgets = budgetService.findBudgets();
				request.setAttribute("budgets", budgets);
				modelAndView.setViewName("/budget/approval-list");
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}
