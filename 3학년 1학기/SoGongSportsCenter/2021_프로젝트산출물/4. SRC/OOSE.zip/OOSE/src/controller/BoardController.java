package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Board;
import service.BoardService;

public class BoardController implements Controller{

	private final BoardService boardService = new BoardService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		
		// 조회
		if(url.equals("/board/board-list")) {
			ArrayList<Board> boards = boardService.findBoards();
			modelAndView.setViewName("board/board-list");
			modelAndView.getModel().put("boards", boards);
		}
		
		// 입력
		else if(url.equals("/board/board-write")) {
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("board/board-write");
			}
			else if(request.getMethod().equals("POST")) {
				Board board = new Board();
				board.setName(request.getParameter("name"));
				board.setPhone_number(request.getParameter("phone_number"));
				board.setPosition(request.getParameter("position"));
				board.setEmployee_classification(request.getParameter("employee_classification"));
				board.setAffiliation(request.getParameter("affiliation"));
				board.setAge(Integer.parseInt(request.getParameter("age")));
				board.setGender(request.getParameter("gender"));
				board.setWorking_status(request.getParameter("working_status"));
				board.setAssignment(request.getParameter("assignment"));
				board.setEducation(request.getParameter("education"));
				board.setMajor(request.getParameter("major"));
				board.setDisabled(request.getParameter("disabled"));
				board.setRewarding_patriotism(request.getParameter("rewarding_patriotism"));
				board.setSalary_peak(request.getParameter("salary_peak"));
				board.setRecruitment(request.getParameter("recruitment"));
				board.setEntered_date(Integer.parseInt(request.getParameter("entered_date")));
				
				boardService.write(board);

				modelAndView.setViewName("index");
				
			}
		}
		// 수정
		else if(url.equals("/board/board-update")) {
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("board/board-update");
			}
			else if(request.getMethod().equals("POST")) {
				Board board = new Board();
				board.setEmployee_id(Long.parseLong(request.getParameter("employee_id")));
				board.setName(request.getParameter("name"));
				board.setPhone_number(request.getParameter("phone_number"));
				board.setPosition(request.getParameter("position"));
				board.setEmployee_classification(request.getParameter("employee_classification"));
				board.setAffiliation(request.getParameter("affiliation"));
				board.setAge(Integer.parseInt(request.getParameter("age")));
				board.setGender(request.getParameter("gender"));
				board.setWorking_status(request.getParameter("working_status"));
				board.setAssignment(request.getParameter("assignment"));
				board.setEducation(request.getParameter("education"));
				board.setMajor(request.getParameter("major"));
				board.setDisabled(request.getParameter("disabled"));
				board.setRewarding_patriotism(request.getParameter("rewarding_patriotism"));
				board.setSalary_peak(request.getParameter("salary_peak"));
				board.setRecruitment(request.getParameter("recruitment"));
				board.setEntered_date(Integer.parseInt(request.getParameter("entered_date")));
				
				boardService.update(board);
				
				modelAndView.setViewName("index");
				
			}
		}
		
		// 삭제
		
		else if(url.equals("/board/board-delete")) {
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("board/board-delete");
			}
			else if(request.getMethod().equals("POST")) {
				Board board = new Board();
				board.setEmployee_id(Long.parseLong(request.getParameter("employee_id")));
				
				boardService.delete(board);

				modelAndView.setViewName("index");
				
			}
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}