package controller;

import java.io.IOException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.LeaveOfAbsence;
import domain.WorkingHours;
import service.LOAService;
import service.WHService;

public class WHController implements Controller{

	
	private final WHService whService = new WHService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		if(url.equals("/wh/childcareTime-applyPeriod-set")) {
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("/wh/childcareTime-applyPeriod-set");
			}
			else if(request.getMethod().equals("POST")) {
				WorkingHours wh = new WorkingHours();
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				String sd = request.getParameter("childcare_apply_set_starting_date");
				System.out.println(df);
				Date startDay = null;
				try {
					startDay = df.parse(sd);
					System.out.println(startDay);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String ed = request.getParameter("childcare_apply_set_quitting_date");
				Date endDay = null;
				try {
					endDay = df.parse(ed);
					System.out.println(endDay);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				wh.setChildcare_apply_set_starting_date(startDay);
				wh.setChildcare_apply_set_quitting_date(endDay);
				WHService.daySet(wh);
				modelAndView.setViewName("index");
			}
		}
		
		else if(url.equals("/wh/overtimeApplyTime-set")) {
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("/wh/overtimeApplyTime-set");
			}
			else if(request.getMethod().equals("POST")) {
				WorkingHours wh = new WorkingHours();
				SimpleDateFormat tf = new SimpleDateFormat("HH:mm");
				String st = request.getParameter("overtime_apply_set_starting_time");
				System.out.println(st);
				Date startTime = null;
				try {
					startTime = tf.parse(st);
					System.out.println(startTime);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String et = request.getParameter("overtime_apply_set_quitting_time");
				System.out.println(et);
				Date endTime = null;
				try {
					endTime = tf.parse(et);
					System.out.println(endTime);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				long timeInMilliSeconds = startTime.getTime();
			    java.sql.Time st1 = new java.sql.Time(timeInMilliSeconds);
			    long timeInMilliSeconds2 = endTime.getTime();
			    java.sql.Time et1 = new java.sql.Time(timeInMilliSeconds2);
				wh.setOvertime_apply_set_starting_time(st1);
				wh.setOvertime_apply_set_quitting_time(et1);
				WHService.timeSet(wh);
				modelAndView.setViewName("index");
			}
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}
