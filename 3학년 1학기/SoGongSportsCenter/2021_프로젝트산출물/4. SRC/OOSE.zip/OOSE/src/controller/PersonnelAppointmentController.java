package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Career;
import domain.PersonnelAppointment;
import service.CareerService;
import service.PersonnelAppointmentService;

public class PersonnelAppointmentController implements Controller{
	private final PersonnelAppointmentService personnelAppointmentService = new PersonnelAppointmentService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ModelAndView modelAndView = new ModelAndView();
		
		if(url.equals("/PersonnelAppointment/Enroll")) {
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("/PersonnelAppointment/Enroll");
			}
			else if(request.getMethod().equals("POST")) {
				PersonnelAppointment perssonelAppointment = new PersonnelAppointment();
				
				perssonelAppointment.setDivision(request.getParameter("division"));
				perssonelAppointment.setPosition(request.getParameter("rank"));
				perssonelAppointment.setEmployee_id(Integer.parseInt(request.getParameter("employee_id")));
				perssonelAppointment.setName(request.getParameter("name"));
				perssonelAppointment.setDepartment(request.getParameter("department"));
				perssonelAppointment.setPersonnel_appointment(request.getParameter("personnel_appointment"));
				perssonelAppointment.setRemarks(request.getParameter("remarks"));
				
				personnelAppointmentService.insert(perssonelAppointment);
				
				modelAndView.setViewName("index");
			}
		}
		else if(url.equals("/PersonnelAppointment/Display")) {
			if(request.getMethod().equals("GET")) {
				ArrayList<PersonnelAppointment> personnelAppointments = personnelAppointmentService.findAll();
				modelAndView.setViewName("/PersonnelAppointment/Display");
				modelAndView.getModel().put("personnelAppointments", personnelAppointments);
			}
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}

}
