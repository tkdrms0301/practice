package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.LaborCost;
import domain.ParticipRate;
import service.LaborCostService;
import service.ParticipRateService;

public class LaborCostController extends HttpServlet implements Controller {
	private final LaborCostService laborcostService = new LaborCostService();

	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ModelAndView modelAndView = new ModelAndView();

		if (url.equals("/laborcost/list")) {
			ArrayList<LaborCost> datas = laborcostService.findAll();
			modelAndView.setViewName("/laborcost/list");
			modelAndView.getModel().put("datas", datas);
		} else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}

}
