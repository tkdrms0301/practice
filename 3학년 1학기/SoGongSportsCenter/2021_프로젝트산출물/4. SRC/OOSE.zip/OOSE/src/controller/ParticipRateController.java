package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.ParticipRate;
import service.ParticipRateService;

public class ParticipRateController extends HttpServlet implements Controller {
	private final ParticipRateService participrateService = new ParticipRateService();

	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ModelAndView modelAndView = new ModelAndView();

		if (url.equals("/participrate/list")) {
			ArrayList<ParticipRate> datas = participrateService.findAll();
			modelAndView.setViewName("/participrate/list");
			modelAndView.getModel().put("datas", datas);
		} else if (url.equals("/participrate/insert")) {
			if (request.getMethod().equals("POST")) {
				ParticipRate rate = new ParticipRate();
				rate.setEmployee_id(Integer.parseInt(request.getParameter("employee_id")));
				rate.setRate(Integer.parseInt(request.getParameter("rate")));
				participrateService.insert(rate);
				modelAndView.setViewName("index");
			}
		} else if (url.equals("/participrate/delete")) {
			if (request.getMethod().equals("POST")) {
				ParticipRate rate = new ParticipRate();
				rate.setParticipRate_id(Integer.parseInt(request.getParameter("participrate_id")));
				participrateService.delete(rate);
				modelAndView.setViewName("index");
			}
		} else if (url.equals("/participrate/update")) {
			if (request.getMethod().equals("POST")) {
				ParticipRate rate = new ParticipRate();
				rate.setParticipRate_id(Integer.parseInt(request.getParameter("participrate_id")));
				rate.setEmployee_id(Integer.parseInt(request.getParameter("employee_id")));
				rate.setRate(Integer.parseInt(request.getParameter("rate")));
				participrateService.update(rate);
				modelAndView.setViewName("index");
				
			}
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}

}