package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.AssStatement;
import service.AssStatementService;

public class AssStatementController implements Controller{

	private final AssStatementService AssStatementService = new AssStatementService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		if(url.equals("/AssStatement/AssStatement-list")) {
			ArrayList<AssStatement> ast = AssStatementService.findAssStatements();
			modelAndView.setViewName("/AssStatement/AssStatement-list");
			modelAndView.getModel().put("AssStatement", ast);
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}
