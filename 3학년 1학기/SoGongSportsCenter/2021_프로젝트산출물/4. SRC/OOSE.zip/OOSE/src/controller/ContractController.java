package controller;

import domain.Contract;
import service.ContractService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ContractController implements Controller {

	ContractService contractService = new ContractService();

	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ModelAndView modelAndView = new ModelAndView();
		if (url.equals("/contract/contract-list")) {
			ArrayList<Contract> contracts = contractService.findContracts();
			modelAndView.setViewName("/contract/contract_list");
			modelAndView.getModel().put("contracts", contracts);

		} else if (url.equals("/contract/register")) {
			if (request.getMethod().equals("GET")) {
				modelAndView.setViewName("/contract/contract_register");
			} else if (request.getMethod().equals("POST")) {
				Contract contract = new Contract();

				contract.setRepresentative(request.getParameter("representative"));
				contract.setContractName(request.getParameter("contractName"));
				contract.setContractMoney(Integer.parseInt(request.getParameter("contractMoney")));
				System.out.println(request.getParameter("contractEndDate"));
				try {
					SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");

					contract.setContractStartDate(
							new Date(transFormat.parse(request.getParameter("contractStartDate")).getTime()));
					contract.setContractEndDate(
							new Date(transFormat.parse(request.getParameter("contractEndDate")).getTime()));

				} catch (ParseException e) {
					e.printStackTrace();
				}

				contract.setRegion(request.getParameter("region"));
				contract.setRemark(request.getParameter("remark"));

				contractService.write(contract);

				modelAndView.setViewName("index");
			}
		} else if (url.equals("/contract/update")) {
			if (request.getMethod().equals("GET")) {
				String contractId = request.getParameter("id");
				Contract contract = contractService.findContractById(contractId);

				modelAndView.getModel().put("contract", contract);
				modelAndView.getModel().put("contractId", contractId);
				modelAndView.setViewName("/contract/contract_update");
			} else if (request.getMethod().equals("POST")) {
				Contract contract = new Contract();

				contract.setContractId(Long.parseLong(request.getParameter("contractId")));
				contract.setRepresentative(request.getParameter("representative"));
				contract.setContractName(request.getParameter("contractName"));
				contract.setContractMoney(Integer.parseInt(request.getParameter("contractMoney")));
				System.out.println(request.getParameter("contractEndDate"));
				try {
					SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");

					contract.setContractStartDate(
							new Date(transFormat.parse(request.getParameter("contractStartDate")).getTime()));
					contract.setContractEndDate(
							new Date(transFormat.parse(request.getParameter("contractEndDate")).getTime()));

				} catch (ParseException e) {
					e.printStackTrace();
				}

				contract.setRegion(request.getParameter("region"));
				contract.setApprovalState(request.getParameter("approvalState"));
				contract.setRemark(request.getParameter("remark"));

				contractService.update(contract);

				modelAndView.setViewName("index");
			}
		} else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}