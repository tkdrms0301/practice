package controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Career;
import service.CareerService;

public class CareerController implements Controller{
	private final CareerService careerService = new CareerService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {
		ModelAndView modelAndView = new ModelAndView();
		
		if(url.equals("/Career/Enroll")) {
			if(request.getMethod().equals("GET")) {
				modelAndView.setViewName("/Career/Enroll");
			}
			else if(request.getMethod().equals("POST")) {
				Career career = new Career();
				
				career.setEducation(request.getParameter("education"));
				career.setTraining(request.getParameter("training"));
				career.setPerformed(request.getParameter("performed"));
				career.setCertificate(request.getParameter("certificate"));
				career.setEvaluation(request.getParameter("evaluation"));
				career.setPrize(request.getParameter("prize"));
				career.setPunishment(request.getParameter("punishment"));
				career.setTask(request.getParameter("task"));
				SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
				java.sql.Date date = java.sql.Date.valueOf(request.getParameter("endtLongevity"));
				career.setLongevity(date);
				career.setEmployee_id(Integer.parseInt(request.getParameter("employee_id")));
				career.setEducation(request.getParameter("job_experience"));
				
				careerService.insert(career);
				
				modelAndView.setViewName("index");
			}
		}
		else if(url.equals("/Career/Display")) {
			if(request.getMethod().equals("GET")) {
				ArrayList<Career> careers = careerService.findAll();
				modelAndView.setViewName("/Career/Display");
				modelAndView.getModel().put("careers", careers);
				if(request.getParameter("id") != null)
				{
					int id = Integer.parseInt(request.getParameter("id"));
					Career career2 = careerService.findById(id);
					modelAndView.getModel().put("career2", career2);
				}
			}
		}
		else if(url.equals("/Career/Update")) {
			if(request.getMethod().equals("GET")) {
				Career career = careerService.findById(Integer.parseInt(request.getParameter("id")));
				modelAndView.setViewName("/Career/Update");
				modelAndView.getModel().put("career", career);
			}
			else if(request.getMethod().equals("POST")) {
				Career career = new Career();
				career.setCareer_id(Integer.parseInt(request.getParameter("career_id")));
				career.setEducation(request.getParameter("education"));
				career.setTraining(request.getParameter("training"));
				career.setPerformed(request.getParameter("performed"));
				career.setCertificate(request.getParameter("certificate"));
				career.setEvaluation(request.getParameter("evaluation"));
				career.setPrize(request.getParameter("prize"));
				career.setPunishment(request.getParameter("punishment"));
				career.setTask(request.getParameter("task"));
				SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
				java.sql.Date date = java.sql.Date.valueOf(request.getParameter("endtLongevity"));
				career.setLongevity(date);
				career.setEmployee_id(Integer.parseInt(request.getParameter("employee_id")));
				career.setJop_experience(request.getParameter("job_experience"));
				careerService.update(career);
				modelAndView.setViewName("index.jsp");
			}
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}

}
