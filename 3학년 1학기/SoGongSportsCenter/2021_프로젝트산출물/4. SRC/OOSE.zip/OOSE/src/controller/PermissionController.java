package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Permission;
import service.PermissionService;

public class PermissionController implements Controller{

	private final PermissionService PermissionService = new PermissionService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		if(url.equals("/Permission/Permission-list")) {
			ArrayList<Permission> per = PermissionService.findPermissions();
			modelAndView.setViewName("/Permission/Permission-list");
			modelAndView.getModel().put("Permission", per);
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}
