package controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.LeaveOfAbsence;
import service.LOAService;

public class LOAController implements Controller{

	
	private final LOAService loaService = new LOAService();
	@Override
	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException {		
		ModelAndView modelAndView = new ModelAndView();
		if(url.equals("/loa/loa-list")) {
			if(request.getMethod().equals("POST")) {
				LeaveOfAbsence loa = new LeaveOfAbsence();
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				String sd = request.getParameter("startPeriodDay");
				System.out.println(df);
				Date startDay = null;
				try {
					startDay = df.parse(sd);
					System.out.println(startDay);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String ed = request.getParameter("endPeriodDay");
				Date endDay = null;
				try {
					endDay = df.parse(ed);
					System.out.println(endDay);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				loa.setStartPeriodDay(startDay);
				loa.setEndPeriodDay(endDay);
				System.out.println(loa);
				ArrayList<LeaveOfAbsence> loas = LOAService.periodFindBoards(loa);
			
				modelAndView.setViewName("/loa/loa-list");
				modelAndView.getModel().put("loas", loas);
			}
			else if(request.getMethod().equals("GET")) {
				ArrayList<LeaveOfAbsence> loas = loaService.findBoards();
				modelAndView.setViewName("/loa/loa-list");
				modelAndView.getModel().put("loas", loas);
			}
			else {
				ArrayList<LeaveOfAbsence> loas = loaService.findBoards();
				modelAndView.setViewName("/loa/loa-list");
				modelAndView.getModel().put("loas", loas);
			}
		
		}
		
		else if(url.equals("/loa/significant-write")) {
			if(request.getMethod().equals("GET")) {
				LeaveOfAbsence loa = new LeaveOfAbsence();
				int id = Integer.parseInt(request.getParameter("leave_of_absence_id"));
				loa.setLeave_of_absence_id(id);
				modelAndView.setViewName("loa/significant-write");
				modelAndView.getModel().put("loa", loa);
			}
			else if(request.getMethod().equals("POST")) {
				LeaveOfAbsence loa = new LeaveOfAbsence();
				int id = Integer.parseInt(request.getParameter("leave_of_absence_id"));
				loa.setLeave_of_absence_id(id);
				loa.setLeaveSignificant(request.getParameter("leaveSignificant"));
				LOAService.write(loa);
				modelAndView.setViewName("index");
			}
		}
		
		else if(url.equals("/loa/significant-update")) {
			if(request.getMethod().equals("GET")) {
				int id = Integer.parseInt(request.getParameter("id"));
				LeaveOfAbsence loa = LOAService.read(id);
				
				modelAndView.setViewName("loa/significant-update");
				modelAndView.getModel().put("loa", loa);
			}
			else if(request.getMethod().equals("POST")) {
				LeaveOfAbsence loa = new LeaveOfAbsence();
				int id = Integer.parseInt(request.getParameter("leave_of_absence_id"));
				loa.setLeave_of_absence_id(id);
				loa.setLeaveSignificant(request.getParameter("leaveSignificant"));
				LOAService.write(loa);
				modelAndView.setViewName("index");
			}
		}
		else {
			modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		return modelAndView;
	}
}
