package controller;

import domain.Contract;
import domain.ContractRequest;
import service.ContractRequestService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ContractRequestController implements Controller {

    ContractRequestService contractRequestService = new ContractRequestService();

    @Override
    public ModelAndView process(HttpServletRequest request, HttpServletResponse response, String url) throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView();
        if (url.equals("/contractRequest/contractRequest-list")) {
            ArrayList<ContractRequest> contractRequests = contractRequestService.findContractRequests();
            modelAndView.setViewName("/contract_request/contract_request_list");
            modelAndView.getModel().put("contractRequests", contractRequests);

        } else if (url.equals("/contractRequest/register")) {
            if (request.getMethod().equals("GET")) {
                modelAndView.setViewName("/contract_request/contract_request_register");
            } else if (request.getMethod().equals("POST")) {
                ContractRequest contractRequest = new ContractRequest();

                contractRequest.setContractName(request.getParameter("contractName"));
                contractRequest.setContractType(request.getParameter("contractType"));

                if (request.getParameter("reannouncement") == null) {
                    contractRequest.setReannouncement(0);
                } else {
                    contractRequest.setReannouncement(Long.parseLong(request.getParameter("reannouncement")));
                }

                if (request.getParameter("newBid") == null){
                    contractRequest.setNewBid(0);
                } else{
                    contractRequest.setNewBid(Long.parseLong(request.getParameter("newBid")));
                }

                try {
                    SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");

                    contractRequest.setRequestDate(new Date(transFormat.parse(request.getParameter("requestDate")).getTime()));

                } catch (ParseException e) {
                    e.printStackTrace();
                }

                contractRequestService.write(contractRequest);

                modelAndView.setViewName("index");
            }
        } else {
            modelAndView.setStatus(HttpServletResponse.SC_NOT_FOUND);
        }
        return modelAndView;
    }
}
